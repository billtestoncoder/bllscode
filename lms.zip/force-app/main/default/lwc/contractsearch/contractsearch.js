import { LightningElement, api, wire  } from 'lwc';
import BuildingQuery from '@salesforce/apex/searchquery.BuildingQuery'
import ContractQuery from '@salesforce/apex/searchquery.ContractQuery'
const BColumns= [
                    {label:'Name', fieldName:'RecordDetails',type:'url', typeAttributes:{label:{fieldName:'Name'}}},
                    {label:'Address', fieldName:'Address', type:'text'},
                    {label:'State', fieldName:'State', type:'text'},
                    {label:'District', fieldName:'District', type:'text'},
                    {label:'Storey', fieldName:'Storey', type:'number'}
                ] 

const UColumns= [
                    {label:'Name', fieldName:'RecordDetails',type:'url', typeAttributes:{label:{fieldName:'Name'}}},
                    {label:'Flatno', fieldName:'Flatno', type:'number'},
                    {label:'FlatType', fieldName:'FlatType', type:'text'},
                    {label:'Floor', fieldName:'State', type:'number'}
                ] 

const CColumns= [
                    {label:'Name', fieldName:'RecordDetails',type:'url', typeAttributes:{label:{fieldName:'Name'}}},
                    {label:'Email', fieldName:'Email', type:'email'},
                    {label:'Phone', fieldName:'Phone', type:'phone'}
                ] 

const CtColumns= [
                    {label:'Name', fieldName:'RecordDetails',type:'url', typeAttributes:{label:{fieldName:'Name'}}},
                    {label:'StartDate', fieldName:'StartDate', type:'date'},
                    {label:'EndDate', fieldName:'EndDate', type:'date'},
                    {label:'TotalPrice', fieldName:'TotalPrice', type:'currency'},
                    {label:'Price', fieldName:'Price', type:'currency'}
                ] 

export default class Contractsearch extends LightningElement {

    BuildingColumns = BColumns;
    UnitColumns = UColumns;
    ContactColumns = CColumns;
    ContractColumns = CtColumns;

    e
    
    BuildingBuffer=[];
    UnitBuffer=[];
    ContactBuffer=[];
    ContractBuffer=[];

    BuildingResult=[];
    UnitResult=[];
    ContractResult=[];
    ContactResult=[];

    value = 'inProgress';

    get options() {
        return [
            { label: 'BuildingName', value: 'BuildingName' },
            { label: 'ContractNo', value: 'ContractNo' },
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
    }
    handlekeyup(e){
        this.e= e.target.value
        if (this.e!==""){
        if (this.value==='BuildingName'){
        BuildingQuery({search: e.target.value}).then(data=>{
            this.BuildingResult=[];
            this.UnitResult=[];
            this.ContractResult=[];
            this.ContactResult=[];
            this.BuildingBuffer=data[0];
            this.UnitBuffer=data[1];
            this.ContactBuffer=data[2];
            this.ContractBuffer=data[3];

            this.BuildingBuffer.forEach(item => {
                var Building={}
                Building.Id= item.id
                Building.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Buildings__c/${item.Id}/view`
                Building.Name=item.Name
                Building.Address = item.Address__c
                Building.State = item.State__c
                Building.District = item.District__c
                Building.Storey = item.Storey__c
                this.BuildingResult.push(Building)
            });

            this.UnitBuffer.forEach(item => {
                var Unit={}
                Unit.Id = item.Id
                Unit.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Units__c/${item.Id}/view`
                Unit.Name=item.Name
                Unit.Flatno = item.Flat_No__c
                Unit.FlatType = item.Flat_Type__c
                Unit.Floor = item.Floor__c
                
                this.UnitResult.push(Unit)
            });

            this.ContactBuffer.forEach(item => {
                var Contact={}
                Contact.Id= item.Id
                Contact.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Contact/${item.Id}/view`
                Contact.Name=item.Name
                Contact.Email = item.Email
                Contact.Phone = item.Phone
                
                this.ContactResult.push(Contact)
            });

            this.ContractBuffer.forEach(item =>{
                var Contract={}
                Contract.Id = item.Id
                Contract.Name = item.Name
                Contract.StartDate = item.Start_Date__c
                Contract.EndDate = item.End_Date__c
                Contract.TotalPrice = item.Total_Price__c
                Contract.Price = item.Price__c
                Contract.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Contracts_c/${item.Id}/view`
                this.ContractResult.push(Contract)
            })
            
           
           
        }).catch(e=>{
            console.log(e)
        });
       }else{
        ContractQuery({search: this.e}).then(data=>{
            console.log(data, this.e )
            this.BuildingBuffer=data[0];
            this.UnitBuffer=data[1];
            this.ContactBuffer=data[2];
            this.ContractBuffer=data[3];
            this.BuildingResult=[];
            this.UnitResult=[];
            this.ContractResult=[];
            this.ContactResult=[];

                this.BuildingBuffer.forEach(item => {
                    var Building={}
                    Building.Id= item.id
                    Building.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Buildings__c/${item.Id}/view`
                    Building.Name=item.Name
                    Building.Address = item.Address__c
                    Building.State = item.State__c
                    Building.District = item.District__c
                    Building.Storey = item.Storey__c
                    this.BuildingResult.push(Building)
                });

                this.UnitBuffer.forEach(item => {
                    var Unit={}
                    Unit.Id = item.Id
                    Unit.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Units__c/${item.Id}/view`
                    Unit.Name=item.Name
                    Unit.Flatno = item.Flat_No__c
                    Unit.FlatType = item.Flat_Type__c
                    Unit.Floor = item.Floor__c
                    
                    this.UnitResult.push(Unit)
                });

                this.ContactBuffer.forEach(item => {
                    var Contact={}
                    Contact.Id= item.Id
                    Contact.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Contact/${item.Id}/view`
                    Contact.Name=item.Name
                    Contact.Email = item.Email
                    Contact.Phone = item.Phone
                    
                    this.ContactResult.push(Contact)
                });

                this.ContractBuffer.forEach(item =>{
                    var Contract={}
                    Contract.Id = item.Id
                    Contract.Name = item.Name
                    Contract.StartDate = item.Start_Date__c
                    Contract.EndDate = item.End_Date__c
                    Contract.TotalPrice = item.Total_Price__c
                    Contract.Price = item.Price__c
                    Contract.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Contracts_c/${item.Id}/view`
                    this.ContractResult.push(Contract)
                })
                
    

        }).catch(e=>{
            console.log(e)
        });
       }}else{
            this.BuildingResult=[];
            this.UnitResult=[];
            this.ContractResult=[];
            this.ContactResult=[];
       }
       
    }
    
        
    


}