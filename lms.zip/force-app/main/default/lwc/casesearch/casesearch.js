import { LightningElement } from 'lwc';
import CaseQuery from '@salesforce/apex/casesearchquery.Casequery';
const CaseColumn = [
                    {label:'Subject', fieldName:'RecordDetails', type:'url',typeAttributes:{label:{fieldName:'Subject'}}},
                    {label:'CaseNumber', fieldName:'CaseNumber', type:'text'},
                    {label:'Origin', fieldName:'Origin', type:'text'},
                    {label:'Reason', fieldName:'Reason', type:'text'},
                   ]

const AccountColumn = [
                    {label:'Account Name', fieldName:'RecordDetails', type:'url',typeAttributes:{label:{fieldName:'Name'}}},           
                    ]
const ContactColumns= [
                        {label:'Name', fieldName:'RecordDetails',type:'url', typeAttributes:{label:{fieldName:'Name'}}},
                        {label:'Email', fieldName:'Email', type:'email'},
                        {label:'Phone', fieldName:'Phone', type:'phone'}
                    ] 
export default class Casesearch extends LightningElement {
    CsColumns = CaseColumn
    AColumns= AccountColumn
    CColumns= ContactColumns
    CaseBuffer=[];
    AccountBuffer=[];
    ContactBuffer=[];
    CaseResult=[];
    AccountResult=[];
    ContactResult=[];

    handlekeyup(e){
        this.e= e.target.value
        CaseQuery({search: e.target.value}).then(data=>{
            this.CaseBuffer=data[0];
            this.AccountBuffer=data[1];
            this.ContactBuffer=data[2];
            this.CaseResult=[];
            this.AccountResult=[];
            this.ContactResult=[];

            this.CaseBuffer.forEach(item => {
                var Case={}
                Case.Id= item.id
                Case.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Case/${item.Id}/view`
                Case.Subject=item.Subject
                Case.CaseNumber = item.CaseNumber
                Case.Origin= item.Origin
                Case.Reason = item.Reason
                this.CaseResult.push(Case)
            });

            this.AccountBuffer.forEach(item => {
                var Account={}
                Account.Id = item.Id
                Account.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Account/${item.Id}/view`
                Account.Name=item.Name
                
                this.AccountResult.push(Account)
            });

            this.ContactBuffer.forEach(item => {
                var Contact={}
                Contact.Id= item.Id
                Contact.RecordDetails=`https://collabera133-dev-ed.lightning.force.com/lightning/r/Contact/${item.Id}/view`
                Contact.Name=item.Name
                Contact.Email = item.Email
                Contact.Phone = item.Phone
                
                this.ContactResult.push(Contact)
            });

           
            
           
           
        }).catch(e=>{
            console.log(e)
        });
    }


}