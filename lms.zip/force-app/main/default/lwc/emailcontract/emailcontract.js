import { LightningElement, api, wire } from 'lwc';
import sendContact from '@salesforce/apex/emailcontract.sendContact';
import pass from './emailcontract.html';
import fail from './failedemailcontract.html';


export default class Emailcontract extends LightningElement {
    @api recordId;
    Discount;
    TotalPrice;
    Price;
    contractName;
    contractId;
    Email;
    BuildingName;
    FlatNumber;
    FullName;
    StartDate;
    EndDate;
    result;
    error;
    display='hide tablemargin'
    handleCloseButtonClick(){
        this.display='hide tablemargin'
    }
    @wire(sendContact,{contractId:'$recordId'})
    contractdata({error,data})
    {if (data){
        this.result=data;
        
    }else{
        
    }}

    render(){
        if (typeof this.result !== 'undefined'){
            return pass;
        }else {
            return fail;
        }
    }
    // connectedCallback(){
    //     console.log('record id: ',this.__recordId)
    //     sendContact({contractId:this.__recordId}).then(contract=>{
    //         this.Discount=contract.Discount__c;
    //         this.TotalPrice=contract.Total_Price__c;
    //         this.Price= contract.Price__c;
    //         this.contractName=contract.Name;
    //         this.contractId=contract.Id;
    //         this.BuildingName=contract.Building_Name__c;
    //         this.FlatNumber= contract.Flat_No__c;
    //         this.FullName = contract.Tenant__r.Name;
    //         this.Email = contract.Tenant__r.Email;
    //         this.StartDate= contract.Start_Date__c;
    //         this.EndDate= contract.End_Date__c;
    //         this.display='tablemargin';
    //     }
            
    //     )
    // }

}