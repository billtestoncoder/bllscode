let i=0
let picturearray=['01.jpg', '02.jpg','03.jpg']
const changeimage=()=>{
    document.getElementById('pug').src=picturearray[i];
    i++;
    if (i>2){
        i=0
    }
}

const slideshowload=()=>{
    setInterval(changeimage,300);
}
window.onload= slideshowload;