let i=0
let j= window.innerWidth -200
let k=0
let n=5
let picturearray=['00.png', '10.png','20.png', '30.png', '40.png', '50.png', '60.png', '70.png']
const changeimage=()=>{
    if (n>0){
        document.getElementById('walker').style.transform="translateX("+k+"px)";
    }else{
        document.getElementById('walker').style.transform="translateX("+k+"px) "+"scaleX(-1)";
    }
    
    document.getElementById('walker').src=picturearray[i];
   
    i++;
    k=k+n;
    if (i>7){
        i=0
    }

    if (k>=j){
        n=n*-1
       
    }else if (k<=0){
        n=n*-1
       
    }
}

const slideshowload=()=>{
    setInterval(changeimage,50);
}
window.onload= slideshowload;