const validation = ()=> {
    let name = document.getElementById('name').value
    let username = document.getElementById('username').value
    let password = document.getElementById('password').value
    let dob = document.getElementById('dob').value
    let namebool=true;
    let passbool=true;
    let datebool=true;
    let unamebool=true;
    if (name==""){
        document.getElementById('nameerror').innerHTML='name is required'
        namebool=false
    }else if ((new RegExp('[0-9]')).test(name)){
        document.getElementById('nameerror').innerHTML='numeric value not allowed'
        namebool=false
    }
    
    if (password==""){
        document.getElementById('passworderror').innerHTML='password is required'
        passbool=false
    }else if (password.length<8 || password.length>16){
        document.getElementById('passworderror').innerHTML='password length should be greater than 8 and less than 16'
        passbool=false
    }else if (!(new RegExp('[0-9]')).test(password)  || !(new RegExp('[A-Z]')).test(password)|| !(new RegExp('[a-z]')).test(password)){
        document.getElementById('passworderror').innerHTML='password should contain atleast 1 lowercase 1 Uppercase and 1 numeric value'
        passbool=false
    }

    if (dob=="" || dob==null){
        document.getElementById('dateerror').innerHTML='date of birth is required'
        datebool=false
    }else {
        console.log(typeof dob)
        let dateob = new Date(dob)
        let date18 = new Date(dateob.getFullYear()+18, dateob.getMonth(),dateob.getDate())
        if (date18>(Date.now())){
            document.getElementById('notif').style.backgroundColor='red';
            document.getElementById('notif').style.color='white';
            document.getElementById('notif').style.visibility='visible';
            document.getElementById('notif').innerHTML='age under 18'
            datebool=false
        }
    }
 

    if (username==""){
        document.getElementById('usernameerror').innerHTML='username is required'
        unamebool=false
    }else if (!(new RegExp("^[a-zA-Z0-9]*$")).test(username)){
        document.getElementById('usernameerror').innerHTML='username should only be alphanumeric'
        unamebool=false
    }else if (username.length>8){
        document.getElementById('usernameerror').innerHTML='username string maximum of 8 characters'
        unamebool=false
    }

    if (unamebool && namebool && passbool && datebool){
        document.getElementById('notif').style.backgroundColor='green';
        document.getElementById('notif').style.color='white';
        document.getElementById('notif').style.visibility='visible';
        document.getElementById('notif').innerHTML='registration successfull'
        document.getElementById('usernameerror').innerHTML=''
        document.getElementById('dateerror').innerHTML=''
        document.getElementById('passworderror').innerHTML=''
        document.getElementById('nameerror').innerHTML=''
    }
}