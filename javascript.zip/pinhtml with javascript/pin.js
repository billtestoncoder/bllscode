const validation =()=>{
    var name = document.getElementById('name').value;
    var dob = document.getElementById('dob').value;
    var phone = document.getElementById('phone').value;
    var nameregex =new RegExp("^[a-zA-Z_ ]*$")
    var phoneregex = new RegExp("^[0-9]");
    var namebool=true;
    var datebool=true;
    var phonebool=true;

    if (name.length<=0){
        document.getElementById("nameerror").innerHTML="name required"
        namebool=false;
    }else if (!nameregex.test(name)){
        document.getElementById("nameerror").innerHTML="name format not followed"
        namebool=false;
    }

    if (phone.length<=0){
        document.getElementById("phoneerror").innerHTML="phone required"
        phonebool=false;
    }else if (phone.length!=10){
        document.getElementById("phoneerror").innerHTML="phone 10 digit format not followed"
        phonebool=false;
    }else if (!phoneregex.test(phone)){
        document.getElementById("phoneerror").innerHTML="phone format not followed"
        phonebool=false;
    }

    if (dob.length<=0){
        document.getElementById("dateerror").innerHTML="date required"
        datebool=false
    }else if (!(typeof (new Date(dob))=='object')){
        document.getElementById("dateerror").innerHTML="date format not followed"
        datebool=false
    }
    console.log()

    if (namebool && datebool && phonebool){
        console.log(dob.split("-"))
        var dates = dob.split("-")[2]+dob.split("-")[1]+dob.split("-")[0].substring(2,4) 
        alert('pin: '+ name.substring(0,4)+dates+phone.substring(5,10))
        document.getElementById("dateerror").innerHTML=""
        document.getElementById("phoneerror").innerHTML=""
        document.getElementById("nameerror").innerHTML=""

    }



}