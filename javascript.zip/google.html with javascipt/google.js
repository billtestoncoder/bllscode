
const gsearch = ()=> {
      var url = 'https://www.google.com/search?q=' + document.getElementById('searchme').value;
      window.open(url, '_blank');
    };
const glucky = ()=> {
      var url = 'https://www.google.com/search?q=' + document.getElementById('searchme').value + '&btnI';
      window.open(url, '_blank');
    };
  

 