import { LightningElement,api } from 'lwc';

export default class Carpartviewer extends LightningElement {

    @api show
    @api carpart
    @api name
    @api model
    @api type
    @api cost
    @api price;
    @api description;
    @api detaileddescription;
    @api base;   
    @api src

    
    @api
    get cpshow(){
        return this.show
    }
    set cpshow(value){
        
        if (value==true){
            console.log(this.carpart)
            this.show=true
            this.name = this.carpart.Name
            this.type = this.carpart.Type__c
            this.cost = Math.round((parseFloat(this.carpart.Pricecost__c)+Number.EPSILON)*100)/100
            this.price = Math.round((parseFloat(this.carpart.Price__c)+Number.EPSILON)*100)/100
            this.profitmargin = Math.round(((this.price/this.cost)-1+Number.EPSILON)*100)/100
            this.base = this.carpart.Base__c
            this.description = this.carpart.Description__c;
            this.detaileddescription = this.carpart.Detailed_Description__c
            this.src = this.carpart.url
        }else{
            this.show=false;
        }
    }

    handleviewClose(){
      
            const ev = new CustomEvent('carpartviewclose', {
                detail:'yes', bubbles:true, composed:true
            },)
            this.dispatchEvent(ev);
            
       
    }

   
}