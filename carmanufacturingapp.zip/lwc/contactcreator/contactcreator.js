import { LightningElement, api } from 'lwc';
import contactcreate from '@salesforce/apex/ContactController.contactcreate'
import contactedit from '@salesforce/apex/ContactController.contactedit'
import accountselectone from '@salesforce/apex/AccountController.accountselectone'
export default class Contactcreator extends LightningElement {
    @api show=false
    @api contact
    @api lead
    @api type='create'
    @api firstname= ''
    @api lastname= ''
    @api title= ''
    @api mobile=''
    @api email=''
    @api status=''
    @api address=''
    @api account=''
    @api modelid
    @api modelname
    @api accountname=''
    @api company=''
   
    @api
    get cmshow(){
        this.show
    }

    set cmshow(value){
       
        this.show=value
        if (value==true){
            
            this.create=this.type=='create'
            this.edit=this.type=='edit'
            if (this.create){
                this.firstname = this.lead.FirstName
                this.lastname = this.lead.LastName 
                this.title = this.lead.Title
                this.mobile = this.lead.Mobile__c
                this.email= this.lead.Email
                this.address= this.lead.Address__c
                this.company= this.lead.Company
            }else{
                
                this.firstname = this.contact.FirstName
                this.lastname = this.contact.LastName 
                this.title = this.contact.Title
                this.mobile = this.contact.Mobile__c
                this.email= this.contact.Email
                this.address= this.contact.Address__c
                this.account= this.contact.AccountId
                this.modelid= this.contact.Car_Model__c
                this.modelname = this.contact.Car_Model__r.Name
                accountselectone({recordId:this.account}).then(data=>{
                    this.accountname=data.Name
                })

            }
        }
    }

    handlefirstnamechange(e){
        this.firstname=e.target.value
    }

    handlelastnamechange(e){
        this.lastname=e.target.value
    }

    handletitlechange(e){
        this.title = e.target.value
    }

    handlemobilechange(e){
        this.mobile = e.target.value
    }

    handleemailchange(e){
        this.email = e.target.value
    }


    handleaddresschange(e){
        this.address = e.target.value
    }

    handleaccountsearch(event){
        console.log(event.detail.data)
        this.account=event.detail.data
        

    }
    
    handleaccountselect(event){
        console.log(event.detail.data)
        this.account=event.detail.data
        accountselectone({recordId:this.account}).then(data=>{
            this.modelid = data.Car_Model__r.Id
            this.modelname= data.Car_Model__r.Name
        })
      
    }
   

    handleSave(){
        const allValid = [
            ...this.template.querySelectorAll('lightning-input'),
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){
            if (this.create){
                contactcreate( {accountId:this.account, mobile:this.mobile, 
                                email:this.email, title:this.title,  Model:this.modelid, company:this.company,
                                firstname:this.firstname, lastname:this.lastname, address:this.address}).then(data=>{
                                const event = new CustomEvent('contactcreatesaved', {
                                    detail: 'saved', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(event);
                            })
            }else if (this.edit){
                contactedit( {recordId:this.contact.Id, accountId:this.account, 
                              mobile:this.mobile, email:this.email, title:this.title,  Model:this.modelid, 
                              firstname:this.firstname, lastname:this.lastname, address:this.address}).then(data=>{
                    const event = new CustomEvent('contacteditsaved', {
                        detail: 'saved', bubbles:true, composed:true
                    },)
                    this.dispatchEvent(event);
                })
                    
            }
        }
    }
    handleClose(){
        if (this.create){
            const event = new CustomEvent('contactcreateclosed', {
                detail: {data:'closed'}, bubbles:true, composed:true
            },)
            this.dispatchEvent(event);
        }else{
            const event = new CustomEvent('contacteditclosed', {
                detail: {data:'closed'}, bubbles:true, composed:true
            },)
            this.dispatchEvent(event);
        }
       
    }


}