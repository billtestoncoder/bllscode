import { LightningElement, api } from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'

const columns =[  
            {label:'Name', fieldName:'Name', type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
            {label:'Type', fieldName:'Type', type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
            {label:'Start Date', fieldName:'StartDate',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
            {label:'End Date', fieldName:'EndDate',type:'text', cellAttributes:{class:{fieldName:'tablestyle'}}},
        
        ]
export default class Campaigntable extends LightningElement {
    columns = columns
    @api campaigndata

    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }
}