import { LightningElement ,api} from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'
const columns = [
    {label:'Car Name', fieldName:'Name',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Car Model', fieldName:'Carname',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label: 'Year',fieldName:'Year__c', type:'number',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label: 'Status',fieldName:'Status__c', type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}}
];


export default class Carmodeltable extends LightningElement {
    @api cmdata;
    @api rId;
    columns = columns;
    show=false

    constructor() {
        super();
        this.columns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })
            // Other column data here
    }
    getRowActions(row, doneCallback) {
        const actions = [];
         if (row.Status__c!='Manufactured' || row.Status__c!='Readyforlaunch'){   
                actions.push({
                    'label': 'View',
                    'iconName': 'utility:record_lookup',
                    'name': 'view'
                });

                actions.push({
                    'label': 'Edit',
                    'iconName': 'utility:edit',
                    'name': 'edit'
                });
                actions.push({
                    'label': 'Delete',
                    'iconName': 'utility:delete',
                    'name': 'delete'
                });
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
        }else{
            actions.push({
                'label': 'View',
                'iconName': 'utility:record_lookup',
                'name': 'view'
            });

            setTimeout(() => {
                doneCallback(actions);
            }, 200);
        }
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
        // const rows = Object.assign({}, this.cdata);
        // const rowIndex = rows.indexOf(row);
        // console.log (Object.assign({}, event.detail.row))
        switch (action.name) {
            case 'view':
                const event = new CustomEvent('carmodelview', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(event);
                
                break;
            case 'delete':
                const evt = new CustomEvent('carmodeldelete', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(evt);
               
                break;
            case 'edit':
                const ev = new CustomEvent('carmodeledit', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(ev);
                break;
        }
    }
    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }
}