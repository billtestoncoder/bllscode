import { LightningElement,api } from 'lwc';
import caredit from '@salesforce/apex/CarController.caredit';
import uploadFile from '@salesforce/apex/FileUploaderClass.uploadFile'
const options = [
    {'label': 'sedan', 'value': 'sedan'},
    {'label': 'suv', 'value': 'suv'}
]

export default class Careditor extends LightningElement {
  
    options=options
    @api cid='';
    @api name='';
    @api type='';
    @api show;
    @api rid;
    @api file;
    @api filechange=false;
    @api filename='';
    @api src="https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder";

    closeshow(e){
        const event = new CustomEvent('editorclosed', {
            detail: {data:e}, bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
        
    }
    handleNameChange(e){
        this.name=e.target.value
    }

    handleTypeChange(e){
        this.type=e.target.value

    }
    handleFilesChange(e) {
        var files = e.target.files;
        var extension= files[0].type;
        this.getBase64(files[0]).then(data=>{
            console.log(data);
            if (extension!='png'){
                var buff = data.split("/")[0].length +data.split("/")[1].length+1
                this.file=data.substring(buff, data.length);
                this.src= URL.createObjectURL(files[0])
                this.filename=files[0].name
                this.filechange=true;
            }
           
        }).catch(error=>{console.log(error)})
    }
    handleeditSave(){
        const allValid = [
            ...this.template.querySelectorAll('lightning-input'),
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){
        caredit({rid:this.cid, name:this.name,type:this.type,page:0,carperpage:25})
        .then(data=>
            {   
                var rows= data;
                this.rid=data[0].Id;
                if(this.filechange){
                uploadFile({base64:this.file,filename:this.filename,recordId:this.rid})
                .then(data=>{
                    this.name=''
                    this.type=''
                    this.filename=''
                    this.filechange=false
                    this.src="https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder";
                    this.closeshow(rows);
                })
                .catch(error=>{console.log(error)})
               }else{
                this.name=''
                this.type=''
                this.filename=''
                this.src="https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder";
                this.filechange=false
                this.closeshow(rows);
               }
            }
        )
        .catch(error=>{console.log(error)})
        }else{
            alert('Please update the invalid form entries and try again.');
        }
    }
    getBase64(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.readAsDataURL(file);
          
          reader.onerror = error => reject(error);
        });
      }
 
}