import { LightningElement, api } from 'lwc';
import carmodelcreate from '@salesforce/apex/CarmodelController.carmodelcreate';
import carpartcreate from '@salesforce/apex/CarpartController.carpartcreate';
import uploadFile from '@salesforce/apex/FileUploaderClass.uploadFile';

const options = [
    {'label': 'white', 'value': 'white'},
    {'label': 'red', 'value': 'red'},
    {'label': 'jade', 'value': 'jade'},
    {'label': 'yellow', 'value': 'yellow'},
    {'label': 'silver', 'value': 'silver'},
    {'label': 'blue', 'value': 'blue'},
    
]
export default class Carmodelcreator extends LightningElement {
options=options
@api show
@api counter=0;

@api clrsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
@api engsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
@api mugsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
@api mufsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
@api sposrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
@api ligsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'

@api clrfile=''
@api engfile=''
@api mugfile=''
@api muffile=''
@api spofile=''
@api ligfile=''

@api clrfilename=''
@api engfilename=''
@api mugfilename=''
@api muffilename=''
@api spofilename=''
@api ligfilename=''

@api clrfilechange=''
@api engfilechange=''
@api mugfilechange=''
@api muffilechange=''
@api spofilechange=''
@api ligfilechange=''

@api name=''
@api year=2022
@api car=''
@api cost=0
@api price=0
@api totalcost=0
@api totalprice=0
@api description='' 
@api detaileddescription='' 
@api profitmargin=0 
@api color=''
@api engine=''
@api enginecost=0
@api engineprice=0
@api enginedescription=''
@api detailedenginedescription=''
@api mugs=''
@api mugscost=0
@api mugsprice=0
@api mugsdescription=''
@api detailedmugsdescription=''
@api muffler=0
@api mufflercost=0
@api mufflerprice=0
@api mufflerdescription=''
@api detailedmufflerdescription=''
@api spoiler=''
@api spoilercost=0
@api spoilerprice=0
@api spoilerdescription=''
@api detailedspoilerdescription=''
@api lights=''
@api lightscost=0
@api lightsprice=0
@api lightsdescription='' 
@api detailedlightsdescription=''

handleNameChange(event){
    console.log(event.target.value)
    this.name=event.target.value
}
handlecarsearch(event){
    console.log(event.detail.data)
    this.car=event.detail.data
}

handlecarselect(event){
    console.log(event.detail.data)
    this.car=event.detail.data
}

handleDescriptionChange(event){
    console.log(event.target.value)
    this.description=event.target.value
}

handleDetailedDescriptionChange(event){
    this.detaileddescription=event.target.value
}
handleProfitMarginChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.profitmargin=Math.round((parseFloat(event.target.value)+Number.EPSILON)*100)/100
        this.price =Math.round((this.cost* (this.profitmargin+1)+Number.EPSILON)*100)/100
        this.engineprice = Math.round(this.enginecost*(this.profitmargin+1)+Number.EPSILON*100)/100
        this.mugsprice =  Math.round(this.mugscost*(this.profitmargin+1)+Number.EPSILON*100)/100
        this.mufflerprice = Math.round(this.mufflercost*(this.profitmargin+1)+Number.EPSILON*100)/100
        this.spoilerprice = Math.round(this.spoilercost*(this.profitmargin+1)+Number.EPSILON*100)/100
        this.lightsprice = Math.round(this.lightscost *(this.profitmargin+1)+Number.EPSILON*100)/100
    }
    
}
handleCostChange(event){
    console.log(event.target.value)


    if(parseFloat(event.target.value)!==NaN){
        this.cost = parseFloat(event.target.value).toFixed(2)
        this.price = (this.cost * (this.profitmargin+1)).toFixed(2)
    }
 
}

handleYearChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.year = parseFloat(event.target.value)
    }
}

handleColorChange(event){
    this.color = event.target.value
}

handleEngineChange(event){
    this.engine = event.target.value
}

handleengineCostChange(event){
    
    if(parseFloat(event.target.value)!==NaN){
        this.enginecost= parseFloat(event.target.value).toFixed(2)
        this.engineprice= (this.enginecost*(this.profitmargin +1)).toFixed(2)
    }
  
}

handleengineDescription(event){
    this.enginedescription=event.target.value
}

handledetailedengineDescription(event){
    this.detailedenginedescription=event.target.value
}

handleMugsChange(event){
    this.mugs = event.target.value
}

handlemugsCostChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.mugscost= parseFloat(event.target.value).toFixed(2)
        this.mugsprice= (this.mugscost* (this.profitmargin+1)).toFixed(2)
    }
}

handlemugsDescription(event){
    this.mugsdescription=event.target.value
}

handledetailedmugsDescription(event){
    this.detailedmugsdescription=event.target.value
}

handleMufflerChange(event){
    this.muffler = event.target.value
}

handlemufflerCostChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.mufflercost= parseFloat(event.target.value).toFixed(2)
        this.mufflerprice= (this.mufflercost* (this.profitmargin+1)).toFixed(2)
    }
}

handlemufflerDescription(event){
    this.mufflerdescription=event.target.value
}

handledetailedmufflerDescription(event){
    this.detailedmufflerdescription=event.target.value
}

handleSpoilerChange(event){
    this.spoiler= event.target.value
}

handlespoilerCostChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.spoilercost= (parseFloat(event.target.value)).toFixed(2)
        this.spoilerprice= (this.spoilercost* (this.profitmargin+1)).toFixed(2)
    }
}

handlespoilerDescription(event){
    this.spoilerdescription=event.target.value
}

handledetailedspoilerDescription(event){
    this.detailedspoilerdescription=event.target.value
}

handleLightsChange(event){
   this.lights=event.target.value
    
}

handlelightsCostChange(event){
    if(parseFloat(event.target.value)!==NaN){
        this.lightscost= parseFloat(event.target.value).toFixed(2)
        this.lightsprice= (this.lightscost* (this.profitmargin+1)).toFixed(2)
    }
}

handlelightsDescription(event){
    this.lightsdescription=event.target.value
}
handledetailedlightsDescription(event){
    this.detailedlightsdescription=event.target.value
}

handlecolorattachment(event){

    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.clrfile=data.substring(buff, data.length);
            this.clrsrc= URL.createObjectURL(files[0])
            this.clrfilename=files[0].name
            this.clrfilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.clrfile=buff;
            this.clrsrc= URL.createObjectURL(files[0])
            this.clrfilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
}

handleengineattachment(event){

    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.engfile=data.substring(buff, data.length);
            this.engsrc= URL.createObjectURL(files[0])
            this.engfilename=files[0].name
            this.engfilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.engfile=buff;
            this.engsrc= URL.createObjectURL(files[0])
            this.engfilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
}

handlemugsattachment(event){
    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.mugfile=data.substring(buff, data.length);
            this.mugsrc= URL.createObjectURL(files[0])
            this.mugfilename=files[0].name
            this.mugfilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.mugfile=buff;
            this.mugsrc= URL.createObjectURL(files[0])
            this.mugfilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
    
}

handlemufflerattachment(event){
    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.muffile=data.substring(buff, data.length);
            this.mufsrc= URL.createObjectURL(files[0])
            this.muffilename=files[0].name
            this.muffilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.muffile=buff;
            this.mufsrc= URL.createObjectURL(files[0])
            this.muffilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
    
}

handlespoilerattachment(event){
    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.spofile=data.substring(buff, data.length);
            this.sposrc= URL.createObjectURL(files[0])
            this.spofilename=files[0].name
            this.spofilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.spofile=buff;
            this.sposrc= URL.createObjectURL(files[0])
            this.spofilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
    
}

handlelightsattachment(event){
    var files = event.target.files;
    var extension= files[0].type;
    this.getBase64(files[0]).then(data=>{
        console.log(data);
        if (extension!='png'){
            var buff = data.split("/")[0].length +data.split("/")[1].length+1
            this.ligfile=data.substring(buff, data.length);
            this.ligsrc= URL.createObjectURL(files[0])
            this.ligfilename=files[0].name
            this.ligfilechange=true
        }else{
            var buff = data.split("base64,")[1]
            this.ligfile=buff;
            this.ligsrc= URL.createObjectURL(files[0])
            this.ligfilename=files[0].name
        }
           
        }).catch(error=>{console.log(error)})
    
}
 
handleSave(){
    const allValid = [ 
        ...this.template.querySelectorAll('lightning-input'),...this.template.querySelectorAll('lightning-textarea')
    ].reduce((validSoFar, inputCmp) => {
        inputCmp.reportValidity();
        return validSoFar && inputCmp.checkValidity();
    }, true);
    if (allValid){
        this.totalcost=this.cost + this.enginecost + this.mugscost + this.mufflercost + this.spoilercost + this.lightscost
        this.totalprice=this.price + this.engineprice + this.mugsprice + this.mufflerprice + this.spoilerprice + this.lightsprice
        carmodelcreate( {Baseprice:this.price, Car: this.car,
            Color:this.color, Cost:this.cost, Description:this.description,
            Detailed_Description:this.detaileddescription, Profit_Margin:this.profitmargin, 	
            Engine:this.engine, Enginecost:this.enginecost,		
            Engineprice:this.engineprice,
            Lights:this.lights, Lightcost:this.lightscost,			
            Lightprice: this.lightsprice,  
            Muffler:this.muffler, Mufflercost: this.mufflercost, Mufflerprice: this.mufflercost, 
            Mugs: this.mugs, Mugcost: this.mugscost,		
            Mugprice: this.mugsprice, 
            Spoilers: this.spoiler,
            SpoilerCost: this.spoilercost,SpoilersPrice: this.spoilerprice,		
            Name:this.name, 								
            Status:'proposed', TotalCost:this.totalcost,					
            TotalPrice:this.totalprice,	Year:this.year,
            page:0, carperpage:2}		
            )
        .then(data=>
            {
                this.rid=data[0].Id;
                this.counter=0  
                


                carpartcreate( {
                                name:this.color, price:0, type:'Color', carmodel:this.rid, 
                                description:'',detailed_description:'',
                                pricecost:0, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    if (this.clrfilechange){
                        uploadFile({base64:this.clrfile,filename:this.clrfilename,recordId:data[0].Id})
                        .then(data=>{
                            this.counter++
                            this.clrfilename=''
                            this.clrfilechange=true
                            this.clrfile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                        })
                        .catch(error=>{console.log(error)})
                    }else{
                        this.counter++
                        this.clrfilename=''
                        this.clrfilechange=true
                        this.clrfile=''
                        if (this.counter==12){
                            this.refresh();
                            this.save()
                        }
                            
                    }  
                }).catch(error=>console.log(error))

                carpartcreate( {
                    name:this.engine, price:this.engineprice, type:'Engine', carmodel:this.rid, 
                    description:this.enginedescription,detailed_description:this.detailedenginedescription,
                    pricecost:this.enginecost, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    if (this.engfilechange){
                        uploadFile({base64:this.engfile,filename:this.engfilename,recordId:data[0].Id})
                        .then(data=>{
                            this.counter++
                            this.engfilename=''
                            this.engfilechange=true
                            this.engfile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                        })
                        .catch(error=>{console.log(error)})
                    }else{
                            this.counter++
                            this.engfilename=''
                            this.engfilechange=true
                            this.engfile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                    } 
                }).catch(error=>console.log(error))    

                carpartcreate( {
                    name:this.mugs, price:this.mugsprice, type:'Mugs', carmodel:this.rid, 
                    description:this.mugsdescription,detailed_description:this.detailedmugsdescription,
                    pricecost:this.mugscost, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    if (this.mugfilechange){
                        uploadFile({base64:this.mugfile,filename:this.mugfilename,recordId:data[0].Id})
                        .then(data=>{
                            this.counter++
                            this.mugfilename=''
                            this.mugfilechange=true
                            this.mugfile=''
                            if (this.counter==12){
                                this.save()
                            }
                        })
                        .catch(error=>{console.log(error)})
                    }else{
                            this.counter++
                            this.mugfilename=''
                            this.mugfilechange=true
                            this.mugfile=''
                    }  
                }).catch(error=>console.log(error))    

                carpartcreate( {
                    name:this.muffler, price:this.mufflerprice, type:'Mufflers', carmodel:this.rid, 
                    description:this.mufflerdescription,detailed_description:this.detailedmufflerdescription,
                    pricecost:this.mufflercost, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    
                if (this.muffilechange){
                    uploadFile({base64:this.muffile,filename:this.muffilename,recordId:data[0].Id})
                    .then(data=>{
                        this.counter++
                        this.muffilename=''
                        this.muffilechange=true
                        this.muffile=''
                        if (this.counter==12){
                            this.refresh();
                            this.save()
                        }
                            })
                            .catch(error=>{console.log(error)})
                }else{
                        this.counter++
                        this.muffilename=''
                        this.muffilechange=true
                        this.muffile=''
                        if (this.counter==12){
                            this.refresh();
                            this.save()
                        }
                }
                }).catch(error=>console.log(error))  

                carpartcreate( {
                    name:this.spoiler, price:this.mufflerprice, type:'Spoilers', carmodel:this.rid, 
                    description:this.mufflerdescription,detailed_description:this.detailedspoilerdescription,
                    pricecost:this.mufflercost, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    if (this.spofilechange){
                        uploadFile({base64:this.spofile,filename:this.spofilename,recordId:data[0].Id})
                        .then(data=>{
                            this.counter++
                            this.spofilename=''
                            this.spofilechange=true
                            this.spofile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                        })
                        .catch(error=>{console.log(error)})
                    }else{
                            this.counter++
                            this.spofilename=''
                            this.spofilechange=true
                            this.spofile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                    }  
                }).catch(error=>console.log(error)) 

                carpartcreate( {
                    name:this.lights, price:this.lightscost, type:'Lights', carmodel:this.rid, 
                    description:this.lightsdescription,detailed_description:this.detailedlightsdescription,
                    pricecost:this.lightscost, base:true, page:0, carperpage:2
                }).then(data=>{
                    this.counter++
                    if (this.ligfilechange){
                        uploadFile({base64:this.ligfile,filename:this.ligfilename,recordId:data[0].Id})
                        .then(data=>{
                            this.counter++
                            this.ligfilename=''
                            this.ligfilechange=true
                            this.ligfile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                        })
                        .catch(error=>{console.log(error)})
                    }else{
                            this.counter++
                            this.ligfilename=''
                            this.ligfilechange=true
                            this.ligfile=''
                            if (this.counter==12){
                                this.refresh();
                                this.save()
                            }
                    }
                }).catch(error=>console.log(error)) 
                
            }


        ).catch(error=>{console.log(error)})
    }else{
        alert('Please update the invalid form entries and try again.');
    }            

}

getBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(file);
      
      reader.onerror = error => reject(error);
    });
  }

closeshow(){
    const event = new CustomEvent('modelclosed', {
        detail: {data:'closed'}, bubbles:true, composed:true
    })
    this.dispatchEvent(event);
    
}
refresh(){
    this.clrsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    this.engsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    this.mugsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    this.mufsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    this.sposrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    this.ligsrc='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'


    this.name=''
    this.car=''
    this.year=2022
    this.cost=0 
    this.price=0 
    this.description='' 
    this.detaileddescription='' 
    this.profitmargin=0 
    this.totalcost=0
    this.totalprice=0

}
save(){
    this.mugs=''
    this.mugscost=0
    this.mugsprice=0
    this.mugsdescription=''
    this.detailedmugsdescription=''
    this.muffler=0
    this.mufflercost=0
    this.mufflerprice=0
    this.mufflerdescription=''
    this.detailedmufflerdescription=''
    this.spoiler=''
    this.spoilercost=0
    this.spoilerprice=0
    this.spoilerdescription=''
    this.detailedspoilerdescription=''
    this.lights=''
    this.lightscost=0
    this.lightsprice=0
    this.lightsdescription='' 
    this.detailedlightsdescription=''
    const event = new CustomEvent('modelsaved', {
        detail: {data:'closed'}, bubbles:true, composed:true
    },)
    this.dispatchEvent(event);
}
}
