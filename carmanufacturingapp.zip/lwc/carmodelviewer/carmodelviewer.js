import { LightningElement, api, track } from 'lwc';

import carpartselect from '@salesforce/apex/CarpartController.carpartselect';
import getUrl from '@salesforce/apex/FileUploaderClass.getUrl';
import getmultiUrl from '@salesforce/apex/FileUploaderClass.getmultiUrl';
import getpdfUrl from '@salesforce/apex/FileUploaderClass.getpdfUrl';

const options = [
    {'label': 'Proposed', 'value': 'Proposed'},
    {'label': 'Manufacturing', 'value': 'Manufactured'},
    {'label': 'Manufactured', 'value': 'Manufactured'},
    {'label': 'Readyforlaunch', 'value': 'Readyforlaunch'},
]
const colorcolumns=[ {'label': 'Color', 'fieldName':"Name", 'type':'text'},]
const partscolumns=[ 
                     {'label': 'Name', 'fieldName':"Name", 'type':'text'},
                     {'label': 'Price', 'fieldName':"Price__c", 'type':'currency'},   
                   ]
const clroptions = [
                    {'label': 'white', 'value': 'white'},
                    {'label': 'red', 'value': 'red'},
                    {'label': 'jade', 'value': 'jade'},
                    {'label': 'yellow', 'value': 'yellow'},
                    {'label': 'silver', 'value': 'silver'},
                    {'label': 'blue', 'value': 'blue'},
                    
                ]

export default class Carmodelviewer extends LightningElement {
    options=options
    clroptions=clroptions
    colorcolumns = colorcolumns
    partscolumns = partscolumns
    @api show;
    @api cmodel
    @api cmdata
    @api carmodelurl
    @api cmId='';
    @api name='';
    @api year=2022
    @api car=''
    @api cost=0
    @api price=0
    @api status=0
    @api totalcost=0
    @api totalprice=0
    @api description='' 
    @api detaileddescription='' 
    @api profitmargin=0 
    @api page=0 
    @api carperpage=25
    
    @api displayengineurl=''
    @api displaymugsurl=''
    @api displaymufflerurl=''
    @api displayspoilersurl=''
    @api displaylightsurl=''
    @api displaycolorurl=''


   
    @api colorurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    @api colorname=''
    
    @api engineprice=0
    @api enginecost=0
    @api enginebase=false
    @api enginedetails=''
    @api enginedescription =''  
    @api enginename=''
    @api engineurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'

    @api mugsprice=0
    @api mugscost=0
    @api mugsbase=false
    @api mugsdetails=''
    @api mugsdescription =''  
    @api mugsname=''
    @api mugsurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'

    @api mufflersprice=0
    @api mufflerscost=0
    @api mufflersbase=false
    @api mufflersdetails=''
    @api mufflersdescription =''  
    @api mufflersname=''
    @api mufflersurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'


    @api spoilersprice=0
    @api spoilerscost=0
    @api spoilersbase=false
    @api spoilersdetails=''
    @api spoilersdescription =''  
    @api spoilersname=''
    @api spoilersurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
    

    @api lightsprice=0
    @api lightscost=0
    @api lightsbase=false
    @api lightsdetails=''
    @api lightsdescription =''  
    @api lightsname=''
    @api lightsurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'

    @api basecolordata=[]
    @api baseenginedata=[]
    @api basemugdata=[]
    @api basemufflerdata=[]
    @api basespoilerdata=[]
    @api baselightdata=[]

    @api colorsdata=[]
    @api enginesdata=[]
    @api mugsdata=[]
    @api mufflersdata=[]
    @api spoilersdata=[]
    @api lightsdata=[]

    @api colorsid=[]
    @api enginesid=[]
    @api mugsid=[]
    @api mufflersid=[]
    @api spoilersid=[]
    @api lightsid=[]

    @api pdfname;
    @api pdffileshow=false;
    @api pdfsrc;
    
 

    colorcolumns = colorcolumns
    partscolumns = partscolumns
    constructor() {
        super();
        this.colorcolumns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })
        this.partscolumns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })
    }    
    getRowActions(row, doneCallback) {
        const actions = [];
         if (row.Status__c!='Readyforlaunch'){   

                actions.push({
                    'label': 'View',
                    'iconName': 'utility:edit',
                    'name': 'view'
                });
               
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
        }else{
           
            setTimeout(() => {
                doneCallback(actions);
            }, 200);
        }
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
        console.log(row)
        switch (row.Type__c) {
            case 'Color':
                this.colorurl=row.url
                this.colorname=row.Name
                break
            case 'Engine':
                this.engineprice=row.Price__c
                this.enginecost=row.Pricecost__c
                this.enginebase=row.Base__c
                this.enginedetails=row.Detailed_Description__c
                this.enginedescription =row.Description__c  
                this.enginename=row.Name
                this.engineurl=row.url
                break
            case 'Mugs':
                this.mugsprice=row.Price__c
                this.mugscost=row.Pricecost__c
                this.mugsbase=row.Base__c
                this.mugsdetails=row.Detailed_Description__c
                this.mugsdescription =row.Description__c  
                this.mugsname=row.Name
                this.mugsurl=row.url
             break
            case 'Mufflers':
                this.mufflersprice=row.Price__c
                this.mufflerscost=row.Pricecost__c
                this.mufflersbase=row.Base__c
                this.mufflersdetails=row.Detailed_Description__c
                this.mufflersdescription =row.Description__c  
                this.mufflersname=row.Name
                this.mufflersurl=row.url
             break
            case 'Spoilers':
                this.spoilersprice=row.Price__c
                this.spoilerscost=row.Pricecost__c
                this.spoilersbase=row.Base__c
                this.spoilersdetails=row.Detailed_Description__c
                this.spoilersdescription =row.Description__c  
                this.spoilersname=row.Name
                this.spoilersurl=row.url
             break
            case 'Lights':
                this.lightsprice=row.Price__c
                this.lightscost=row.Pricecost__c
                this.lightsbase=row.Base__c
                this.lightsdetails=row.Detailed_Description__c
                this.lightsdescription =row.Description__c  
                this.lightsname=row.Name
                this.lightsurl=row.url
             break
                
        }
    }

    @api 
    get cmshow(){
        return this.cmshow
    }
    set cmshow(value){
    this.show=value
     if (value==true){
       
       this.cmodel =this.cmdata
       this.cmId = this.cmdata.Id;
       this.car = this.cmdata.Car__r.Name
       this.name = this.cmdata.Name
       this.price= Math.round((parseFloat(this.cmdata.Baseprice__c)+Number.EPSILON)*100)/100 
       this.color= this.cmdata.Color__c 
       this.cost = Math.round((parseFloat(this.cmdata.Cost__c)+Number.EPSILON)*100)/100 
       this.description=this.cmdata.Description__c 
       this.detaileddescription= this.cmdata.Detailed_Description__c 
       this.profitmargin= Math.round((((this.price/this.cost)-1)+Number.EPSILON)*100)/100
       this.status= this.cmdata.Status__c
       this.totalcost= Math.round((parseFloat(this.cmdata.TotalCost__c)+Number.EPSILON)*100)/100
       this.totalprice	=Math.round((parseFloat(this.cmdata.TotalPrice__c)+Number.EPSILON)*100)/100
       this.year = this.cmdata.Year__c
       getpdfUrl({recordId:this.cmId}).then(data=>{
            if(data==null){
                this.pdfsrc=null
                this.pdfname=null
                this.pdffileshow=false;    
            }else{
                this.pdfsrc=data[0]
                this.pdfname=data[1]
                this.pdffileshow=true
            } 
        })
        carpartselect({page:this.page,carperpage:this.carperpage,part:'Color', Ids: this.cmId})
        .then(data=>{
                
                 if (data){
                     
                     data.forEach(d=>{
                             
                           
                             if (d.Base__c){
                                
                                 getUrl({recordId:d.Id}).then(data=>{
                                    console.log(d.Id)
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                     this.displaycolorurl=data
                                    //  this.colorurl=data
                                     datus.Price__c=0;
                                     datus.Pricecost__c=0;
                                     this.basecolordata=[datus]
                                     
                                 }).catch(e=>console.log(e))
                             }else{
                                this.colorsdata.push(d)
                                this.colorsid.push(d.Id)
                             }
                         
                         }
                    
                     )
                     if (this.colorsid.length>0){
                        getmultiUrl({recordIds:this.colorsid}).then(data=>{
                            this.colorsdata=this.colorsdata.map(d=> {return {...d,url:data[d.Id]}} )
                        }
                        
                     )

                     }
                        
                        
                 }
            }).catch(error=>console.log(error))

        carpartselect({page:this.page,carperpage:this.carperpage,part:'Engine', Ids: this.cmId})
        .then(data=>{
                    
                     if (data){
                         
                         data.forEach(d=>{
                                 
                                
                                 if (d.Base__c){
                                    
                                     
                                     getUrl({recordId:d.Id}).then(data=>{
                                         var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                         this.baseenginedata=[datus]
                                         this.displayengineurl=data
                                     }).catch(e=>console.log(e))
                                 }else{
                                    this.enginesdata.push(d)
                                    this.enginesid.push(d.Id)
                                 }
                             
                             }
                        
                         )
                         if (this.enginesid.length>0){
                            getmultiUrl({recordIds:this.enginesid}).then(data=>{
                                this.enginesdata=this.enginesdata.map(d=> {return {...d,url:data[d.Id]}} )
                            }
                            
                         )
    
                         }
                            
                            
                     }
                }).catch(error=>console.log(error))
        
        carpartselect({page:this.page,carperpage:this.carperpage,part:'Mugs', Ids: this.cmId})
        .then(data=>{
                            
                             if (data){
                                 
                                 data.forEach(d=>{
                                         
                                        
                                         if (d.Base__c){
                                            
                                             
                                             getUrl({recordId:d.Id}).then(data=>{
                                                 var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                                 this.basemugdata=[datus]
                                                 this.displaymugsurl=data
                                                 
                                             }).catch(e=>console.log(e))
                                         }else{
                                            this.mugsdata.push(d)
                                            this.mugsid.push(d.Id)
                                         }
                                     
                                     }
                                
                                 )
                                 if (this.mugsid.length>0){
                                    getmultiUrl({recordIds:this.mugsid}).then(data=>{
                                        this.mugsdata=this.mugsdata.map(d=> {return {...d,url:data[d.Id]}} )
                                    }
                                    
                                 )
            
                                 }
                                    
                                    
                             }
        }).catch(error=>console.log(error))
        
        carpartselect({page:this.page,carperpage:this.carperpage,part:'Mufflers', Ids: this.cmId})
        .then(data=>{
                            
                             if (data){
                                 
                                 data.forEach(d=>{
                                         
                                        
                                         if (d.Base__c){
                                            
                                             
                                             getUrl({recordId:d.Id}).then(data=>{
                                                 var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                                 this.basemufflerdata=[datus]
                                                 this.displaymufflersurl=data
                                                 
                                             }).catch(e=>console.log(e))
                                         }else{
                                            this.mufflersdata.push(d)
                                            this.mufflersid.push(d.Id)
                                         }
                                     
                                     }
                                
                                 )
                                 if (this.mufflersid.length>0){
                                    getmultiUrl({recordIds:this.mufflersid}).then(data=>{
                                        this.mufflersdata=this.mufflersdata.map(d=> {return {...d,url:data[d.Id]}} )
                                    }
                                    
                                 )
            
                                 }
                                    
                                    
                             }
        }).catch(error=>console.log(error))

        carpartselect({page:this.page,carperpage:this.carperpage,part:'Spoilers', Ids: this.cmId})
        .then(data=>{
                            
                             if (data){
                                 
                                 data.forEach(d=>{
                                         
                                        
                                         if (d.Base__c){
                                            
                                             
                                             getUrl({recordId:d.Id}).then(data=>{
                                                 var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                                 this.basespoilerdata=[datus]
                                                 this.displayspoilersurl=data
                                             }).catch(e=>console.log(e))
                                         }else{
                                            this.spoilersdata.push(d)
                                            this.spoilersid.push(d.Id)
                                         }
                                     
                                     }
                                
                                 )
                                 if (this.spoilersid.length>0){
                                    getmultiUrl({recordIds:this.spoilersid}).then(data=>{
                                        this.spoilersdata=this.spoilersdata.map(d=> {return {...d,url:data[d.Id]}} )
                                    }
                                    
                                 )
            
                                 }
                                    
                                    
                             }
        }).catch(error=>console.log(error))

        carpartselect({page:this.page,carperpage:this.carperpage,part:'Lights', Ids: this.cmId})
        .then(data=>{
                            
                             if (data){
                                 
                                 data.forEach(d=>{
                                         
                                        
                                         if (d.Base__c){
                                            
                                             
                                             getUrl({recordId:d.Id}).then(data=>{
                                                 var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data}
                                                 this.baselightdata=[datus]
                                                 this.displaylightsurl=data
                                                 
                                             }).catch(e=>console.log(e))
                                         }else{
                                            this.lightsdata.push(d)
                                            this.lightsid.push(d.Id)
                                         }
                                     
                                     }
                                
                                 )
                                 if (this.lightsid.length>0){
                                    getmultiUrl({recordIds:this.lightsid}).then(data=>{
                                        this.lightsdata=this.lightsdata.map(d=> {return {...d,url:data[d.Id]}} )
                                    }
                                    
                                 )
            
                                 }
                                    
                                    
                             }
        }).catch(error=>console.log(error))
     }else{
        this.show=false
     }
    }

    handleClose(){
        const ev = new CustomEvent('carmodelviewclose', {
            detail:'yes', bubbles:true, composed:true
        },)
        this.dispatchEvent(ev);
    }


}