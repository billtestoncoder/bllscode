import { LightningElement, api } from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'

const columns =[  
                    {label:'Name', fieldName:'Name', type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
                    {label:'Model', fieldName:'CarModelName', type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
        
                ]

export default class Accounttable extends LightningElement {

    columns = columns
    @api accountdata

    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }
}