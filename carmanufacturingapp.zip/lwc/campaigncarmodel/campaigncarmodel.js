import { LightningElement, api } from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'

const columns = [
                    {label:'Name', fieldName:'Name',cellAttributes:{class:{fieldName:'tablestyle'}}}, 
                    {label:'Price', fieldName:'TotalPrice__c',cellAttributes:{class:{fieldName:'tablestyle'}}}
                ]
export default class Campaigncarmodel extends LightningElement {
    isCssLoaded=false
    columns= columns;
    @api cmdata
    
    constructor() {
        super();
        this.columns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })

    }
    getRowActions(row, doneCallback) {
        const actions = [];
 
                actions.push({
                    'label': 'view',
                    'iconName': 'utility:record_lookup',
                    'name': 'view'
                });

                actions.push({
                    'label': 'generate campaign',
                    'iconName': 'utility:edit',
                    'name': 'edit'
                });
               
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
       
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
    
        switch (action.name) {
            case 'view':
                const event = new CustomEvent('campaigncarmodelview', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(event);
                
                break;
        
            case 'edit':
                const ev = new CustomEvent('campaigncreateview', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(ev);
                break;
        }
    }

    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }
}