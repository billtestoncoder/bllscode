import { LightningElement, api } from 'lwc';
import campaigncreate from '@salesforce/apex/CampaignController.campaigncreate'

export default class Campaigncreator extends LightningElement {
    @api show
    @api cmname;
    @api cmid;

    @api campaigname=''
    @api campaigntype='Advertisement'
    @api startdate=''
    @api enddate=''

    @api 
    get cmshow(){
        this.show
    }

    set cmshow(value){
        console.log(value)
        this.show=value
        if (value==true){
            this.campaigname=''
            this.startdate=''
            this.enddate=''
        }
    }

    handlenamechange(e){
        this.campaigname=e.target.value
    }

    handlestartdatechange(e){
        let raw = e.target.value
        this.startdate=raw.split("-")[1]+"/"+raw.split("-")[2]+"/"+raw.split("-")[0]
        
    }

    handleenddatechange(e){
        let raw = e.target.value
        this.enddate=raw.split("-")[1]+"/"+raw.split("-")[2]+"/"+raw.split("-")[0]
   
    }

    handleSave(){
        const allValid = [ 
            ...this.template.querySelectorAll('lightning-input')
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){ 
            campaigncreate({name:this.campaigname, starts:this.startdate, ends:this.enddate, 
                            type:this.campaigntype, Model:this.cmid})
                            .then(data=>{
                                const event = new CustomEvent('campaignsave', {
                                    detail: 'done', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(event);
                            })
        }
}

    handleClose(e){
        const event = new CustomEvent('campaignclose', {
            detail: {data:e}, bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
    }



}