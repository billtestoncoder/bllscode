import { LightningElement, api } from 'lwc';
import accountcreate from '@salesforce/apex/AccountController.accountcreate'

export default class Accountcreator extends LightningElement {
    @api show
    @api cmname;
    @api cmid;

    @api accountame=''
    @api accounttype='Advertisement'

    @api 
    get cmshow(){
        this.show
    }

    set cmshow(value){
        console.log(value)
        this.show=value
        if (value==true){
            this.accountame=''
 
        }
    }

    handlenamechange(e){
        this.accountame=e.target.value
    }

 

    handleSave(){
        const allValid = [ 
            ...this.template.querySelectorAll('lightning-input')
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){ 
            accountcreate({name:this.accountame,  Model:this.cmid})
                            .then(data=>{
                                const event = new CustomEvent('accountsave', {
                                    detail: 'done', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(event);
                            })
        }
}

    handleClose(e){
        const event = new CustomEvent('accountclose', {
            detail: {data:e}, bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
    }
}