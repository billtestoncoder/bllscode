import { LightningElement, api } from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'
const columns = [
    {label:'First Name', fieldName:'FirstName',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Last Name', fieldName:'LastName',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Mobile', fieldName:'Mobile__c',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Email', fieldName:'Email',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
];
export default class Contacttable extends LightningElement {
    columns=columns
    @api contactdata;
    isCssLoaded = false
    columns = columns;

    

    constructor() {
        super();
        this.columns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions }, cellAttributes:{class:{fieldName:'tablestyle'}} })
            // Other column data here
    }

    getRowActions(row, doneCallback) {
        const actions = [];
            
                actions.push({
                    'label': 'edit',
                    'iconName': 'utility:record_lookup',
                    'name': 'edit'
                });
                actions.push({
                    'label': 'generate booking',
                    'iconName': 'utility:record_lookup',
                    'name': 'booking'
                });
            
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
       
        switch (action.name) {
            case 'booking':
                const event = new CustomEvent('createbooking', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(event);
                
            case 'edit':
                const ev = new CustomEvent('contactedit', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(ev);
                break;
        }
                
           
    }
    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }
}