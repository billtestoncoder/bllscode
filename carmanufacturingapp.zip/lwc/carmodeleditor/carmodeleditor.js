import { LightningElement, api, track } from 'lwc';
import carpartselect from '@salesforce/apex/CarpartController.carpartselect';
import carpartedit from '@salesforce/apex/CarpartController.carpartedit';
import carmodeledit from '@salesforce/apex/CarmodelController.carmodeledit';
import getUrl from '@salesforce/apex/FileUploaderClass.getUrl';
import uploadFile from '@salesforce/apex/FileUploaderClass.uploadFile';
import getpdfUrl from '@salesforce/apex/FileUploaderClass.getpdfUrl';
import uploadpdfFile from '@salesforce/apex/FileUploaderClass.uploadpdfFile';
import deletepdfFiles from '@salesforce/apex/FileUploaderClass.deletepdfFiles';

const options = [
    {'label': 'Proposed', 'value': 'Proposed'},
    {'label': 'Manufacturing', 'value': 'Manufactured'},
    {'label': 'Manufactured', 'value': 'Manufactured'},
    {'label': 'Readyforlaunch', 'value': 'Readyforlaunch'},
]
const colorcolumns=[ {'label': 'Color', 'fieldName':"Name", 'type':'text'},]
const partscolumns=[ 
                     {'label': 'Name', 'fieldName':"Name", 'type':'text'},
                     {'label': 'Price', 'fieldName':"Price__c", 'type':'currency'},   
                   ]
const clroptions = [
                    {'label': 'white', 'value': 'white'},
                    {'label': 'red', 'value': 'red'},
                    {'label': 'jade', 'value': 'jade'},
                    {'label': 'yellow', 'value': 'yellow'},
                    {'label': 'silver', 'value': 'silver'},
                    {'label': 'blue', 'value': 'blue'},
                    
                ]
export default class Carmodeleditor extends LightningElement {
    options=options
    clroptions=clroptions
    counter=0
    @api show;
    @api cmodel
    @api carmodelurl
    @api cmId='';
    @api name='';
    @api year=2022
    @api car=''
    @api cost=0
    @api price=0
    @api status=0
    @api totalcost=0
    @api totalprice=0
    @api description='' 
    @api detaileddescription='' 
    @api profitmargin=0 
    @api page=0 
    @api carperpage=25
    
    @api colors=[]
    @api engines=[]
    @api mufflers=[]
    @api mugs=[]
    @api lights=[]
    @api spoilers=[]

    @api basecolors=[]
    @api baseengines=[]
    @api basemufflers=[]
    @api basemugs=[]
    @api baselights=[]
    @api basespoilers=[]

    @api basecoloredit=false
    @api baseengineedit=false
    @api basemuffleredit=false
    @api basemugedit=false
    @api baselightedit=false
    @api basespoileredit=false

    @api basecolorurl=''
    @api baseengineurl=''
    @api basemufflerurl=''
    @api basemugurl=''
    @api baselighturl=''
    @api basespoilerurl=''

    @api basecolorprice=0
    @api basecolorcost=0
    @api baseengineprice=0
    @api baseenginecost=0
    @api basemufflerprice=0
    @api basemufflercost=0
    @api basemugprice=0
    @api basemugcost=0
    @api baselightprice=0
    @api baselightcost=0
    @api basespoilerprice=0
    @api basespoilercost=0

    @api basecolordata=[]
    @api baseenginedata=[]
    @api basemufflerdata=[]
    @api basemugdata=[]
    @api baselightdata=[]
    @api basespoilerdata=[]
    @api carmodelchange=''
    @api cmdata=[];

    @api progress=0;

    @api pdf;
    @api pdfname;
    @api pdfchange;
    @api pdfloadshow=false;
    @api pdffileshow=false;
    @api pdfsrc;
    @api pdferror=false;
    @api pdferrormsg='upload not successful';

    @api clrprice=0;
    @api clrcost=0;
    @api clrdescription='';
    @api clrdetaileddescription='';

    colorcolumns = colorcolumns
    partscolumns = partscolumns
    constructor() {
        super();
        this.colorcolumns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })
        this.partscolumns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions } })
    }    
    getRowActions(row, doneCallback) {
        const actions = [];
         if (row.Status__c!='Readyforlaunch'){   

                actions.push({
                    'label': 'Edit',
                    'iconName': 'utility:edit',
                    'name': 'edit'
                });
               
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
        }else{
           
            setTimeout(() => {
                doneCallback(actions);
            }, 200);
        }
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
        // const rows = Object.assign({}, this.cdata);
        // const rowIndex = rows.indexOf(row);
        // console.log (Object.assign({}, event.detail.row))
        switch (row.Type__c) {
            case 'Color':
             this.basecoloredit=false
             this.basecolors.edited=false
             break
            case 'Engine':
             this.baseengineedit=false
             this.baseengines.edited=false
             break
            case 'Mugs':
             this.basemugedit=false
             this.basemugs.edited=false
             break
            case 'Mufflers':
             this.basemuffleredit=false
             this.basemufflers.edited=false
             break
            case 'Spoilers':
             this.basespoileredit=false
             this.basespoilers.edited=false
             break
            case 'Lights':
             this.baselightedit=false
             this.baselights.edited=false
             break
                
        }
    }

    @api
    get cmshow(){
        return this.show
    }
    set cmshow(value){
      
        this.show=value
        if (value==true){
            this.basecoloredit=true;
            this.baseengineedit=true;
            this.basemugedit=true;
            this.basemuffleredit=true;
            this.basespoileredit=true;
            this.baselightedit=true;
            this.cmodel =this.cmdata
            this.cmId = this.cmdata.Id;
            this.car = this.cmdata.Car__r.Name
            this.name = this.cmdata.Name
            this.price= Math.round((parseFloat(this.cmdata.Baseprice__c)+Number.EPSILON)*100)/100 
            this.color= this.cmdata.Color__c 
            this.cost = Math.round((parseFloat(this.cmdata.Cost__c)+Number.EPSILON)*100)/100 
            this.description=this.cmdata.Description__c 
            this.detaileddescription= this.cmdata.Detailed_Description__c 
            this.profitmargin= Math.round((((this.price/this.cost)-1)+Number.EPSILON)*100)/100
            this.status= this.cmdata.Status__c
            this.totalcost= Math.round((parseFloat(this.cmdata.TotalCost__c)+Number.EPSILON)*100)/100
            this.totalprice	=Math.round((parseFloat(this.cmdata.TotalPrice__c)+Number.EPSILON)*100)/100
            this.year = this.cmdata.Year__c
            getpdfUrl({recordId:this.cmId}).then(data=>{
                 if(data==null){
                     this.pdfsrc=null
                     this.pdfname=null
                     this.pdffileshow=false;    
                 }else{
                     this.pdfsrc=data[0]
                     this.pdfname=data[1]
                     this.pdffileshow=true
                 } 
                
             
             })
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Color', Ids: this.cmId})
            .then(data=>{
                
                 if (data){
                     
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name}
                             if (datus.Base__c){
                                 this.basecolors=datus
                                 
                                 getUrl({recordId:this.basecolors.Id}).then(data=>{
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.basecoloredit,file:'',filename:'',filechange:false}
                                     datus.Price__c=0;
                                     datus.Pricecost__c=0;
                                     this.basecolors=datus
                                     this.basecolorprice=0
                                     this.basecolorcost=0
                                     
                                     this.basecolorurl=data
                                     // console.log(this.basecolors)
                                     this.basecolordata=[this.basecolors]
                                 }).catch(e=>console.log(e))
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Engine', Ids: this.cmId})
            .then(data=>{
             
                 if (data){
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name}
                             if (datus.Base__c){
                                 this.baseengines=datus
                                 
                                 getUrl({recordId:this.baseengines.Id}).then(data=>{
                                     // console.log(data)
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.baseengineedit,file:'',filename:'',filechange:false}
                                     datus.Pricecost__c= Math.round((parseFloat(datus.Pricecost__c)+Number.EPSILON)*100)/100
                                     datus.Price__c = Math.round((parseFloat(datus.Price__c)+Number.EPSILON)*100)/100
                                     this.baseengines=datus
                                     this.baseengineurl=data
                                     this.baseengineprice=this.baseengines.Price__c
                                     this.baseenginecost=this.baseengines.Pricecost__c
                                     this.baseenginedata=[this.baseengines]
                                 }).catch(e=>console.log(e))
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Mugs', Ids: this.cmId})
            .then(data=>{
                 if (data){
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name,edited:true}
                             if (datus.Base__c){
                                 this.basemugs=datus
                                 
                                 getUrl({recordId:this.basemugs.Id}).then(data=>{
                                    
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.basemugedit,file:'',filename:'',filechange:false}
                                     datus.Pricecost__c= Math.round((parseFloat(datus.Pricecost__c)+Number.EPSILON)*100)/100
                                     datus.Price__c = Math.round((parseFloat(datus.Price__c)+Number.EPSILON)*100)/100
                                     this.basemugs=datus
                                     this.basemugurl=data
                                     this.basemugprice=this.basemugs.Price__c
                                     this.basemugcost=this.basemugs.Pricecost__c
                                     this.basemugdata=[this.basemugs]
                                 }).catch(e=>console.log(e))
                             }else{
                                 this.mugs.push(datus)
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Mufflers', Ids: this.cmId})
            .then(data=>{
                 if (data){
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name,edited:true}
                             if (datus.Base__c){
                                 this.basemufflers=datus
                                 
                                 this
                                 getUrl({recordId:this.basemufflers.Id}).then(data=>{
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.basemuffleredit,file:'',filename:'',filechange:false}
                                     datus.Pricecost__c= Math.round((parseFloat(datus.Pricecost__c)+Number.EPSILON)*100)/100
                                     datus.Price__c = Math.round((parseFloat(datus.Price__c)+Number.EPSILON)*100)/100
                                     this.basemufflers=datus
                                     this.basemufflerurl=data
                                     this.basemufflerprice=this.basemufflers.Price__c
                                     this.basemufflercost=this.basemufflers.Pricecost__c
                                     this.basemufflerdata=[this.basemufflers]
                                 }).catch(e=>console.log(e))
     
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Spoilers', Ids: this.cmId})
            .then(data=>{
                 if (data){
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name,edited:true}
                             if (datus.Base__c){
                                 this.basespoilers=datus
                                 
                                 getUrl({recordId:this.basespoilers.Id}).then(data=>{
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.basespoileredit,file:'',filename:'',filechange:false}
                                     datus.Pricecost__c= Math.round((parseFloat(datus.Pricecost__c)+Number.EPSILON)*100)/100
                                     datus.Price__c = Math.round((parseFloat(datus.Price__c)+Number.EPSILON)*100)/100
                                     this.basespoilers=datus
                                     this.basespoilerurl=data
                                     this.basespoilerprice=this.basespoilers.Price__c
                                     this.basespoilercost=this.basespoilers.Pricecost__c
                                     this.basespoilerdata=[this.basespoilers]
                                 }).catch(e=>console.log(e))
     
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
     
            carpartselect({page:this.page,carperpage:this.carperpage,part:'Lights', Ids: this.cmId})
            .then(data=>{
                 if (data){
                     data.forEach(d=>{
                             
                             var datus = {...d, Carmodelname:d.Car_Model__r.Name,edited:true}
                             if (datus.Base__c){
                                 this.baselights=datus
                                 getUrl({recordId:this.baselights.Id}).then(data=>{
                                     // console.log(data)
                                     var datus = {...d, Carmodelname:d.Car_Model__r.Name,url:data,edited:this.baselightedit,file:'',filename:'',filechange:false}
                                     datus.Pricecost__c= Math.round((parseFloat(datus.Pricecost__c)+Number.EPSILON)*100)/100
                                     datus.Price__c = Math.round((parseFloat(datus.Price__c)+Number.EPSILON)*100)/100
                                     this.baselights=datus
                                     this.baselighturl=data
                                     this.baselightprice=this.baselights.Price__c
                                     this.baselightcost=this.baselights.Pricecost__c
                                     this.baselightdata=[this.baselights]
                                 }).catch(e=>console.log(e))
                             }
                         
                         }
                     )
                 }
            }).catch(error=>console.log(error))
         }
    }
    
    


    closeshow(e){
        const event = new CustomEvent('editorclosed', {
            detail: {data:e}, bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
        
    }
    handlenameChange(event){
        this.name=event.target.value
    }

    handlestatusChange(event){
        this.status=event.target.value
    }
  
    handledescritionChange(event){
        this.description=event.target.value
    }

    handledetaileddescriptionChange(event){
        this.detaileddescription= event.target.value
    }

    handleyearChange(event){
        if(parseFloat(event.target.value)!==NaN){
            this.year=parseFloat(event.target.value)
        }
    }

    handlecostChange(event){
        if(parseFloat(event.target.value)!==NaN){
            this.cost=Math.round((parseFloat(event.target.value)+Number.EPSILON)*100)/100
            this.price=Math.round((this.cost*(1+this.profitmargin)+Number.EPSILON)*100)/100
            this.totalcost=this.cost + this.baseengines.Pricecost__c + 
                           this.basemugs.Pricecost__c + this.basemufflers.Pricecost__c +
                           this.baselights.Pricecost__c + this.basespoilers.Pricecost__c
            this.totalprice= Math.round((this.totalcost * (1+ this.profitmargin)+Number.EPSILON)*100)/100
        }
    }    
    

    handleprofitmarginChange(event){
        if(parseFloat(event.target.value)!==NaN){
            this.profitmargin=Math.round((parseFloat(event.target.value)+Number.EPSILON)*100)/100;
            
            this.price= Math.round(((this.cost*(1+this.profitmargin))+Number.EPSILON)*100)/100
            this.totalprice = Math.round(((this.totalcost*(1+this.profitmargin))+Number.EPSILON)*100)/100
            this.baseengines.Price__c = Math.round((this.baseengines.Pricecost__c*(1+this.profitmargin)+Number.EPSILON)*100)/100
            this.basemugs.Price__c = Math.round(((this.basemugs.Pricecost__c*(1+this.profitmargin))+Number.EPSILON)*100)/100
            this.basemufflers.Price__c = Math.round(((this.basemufflers.Pricecost__c*(1+this.profitmargin))+Number.EPSILON)*100)/100
            this.baselights.Price__c =  Math.round(((this.baselights.Pricecost__c*(1+this.profitmargin))+Number.EPSILON)*100)/100
            this.basespoilers.Price__c=  Math.round(((this.basespoilers.Pricecost__c*(1+this.profitmargin))+Number.EPSILON)*100)/100
            var engine=this.engines.map(d=>{
                var engine= d
                var cost = Math.round((parseFloat(d.Pricecost__c)+Number.EPSILON)*100)/100
                engine.Pricecost__c= cost
                engine.Price__c=Math.round(cost*((1+this.profitmargin)+Number.EPSILON)*100)/100
                return engine
            })
            this.engines=engine
        }
    }
   
    
    handlePdfChange(e) {
        this.progress=0;
        this.pdfchange=false;
        this.pdferror=false;
      
        var upProg=setInterval(this.updateProgress.bind(this),150);
        
        this.pdfloadshow=true;
        var files = e.target.files;
        var extension= files[0].type;
        this.getPdfBase64(files[0]).then(data=>{
            // console.log(extension)
           
               
                this.pdf=data
                this.pdfname=files[0].name
                this.pdfchange=true;
                this.pdffileshow=true;
                uploadpdfFile({base64:this.pdf, filename:this.pdfname, recordId: this.cmId})
                .then(data=>{
                    
                    getpdfUrl({recordId:this.cmId}).then(data=>{
                        
                        this.pdfsrc=data[0]
                        clearInterval(upProg)
                        this.progress=100
                        
                        this.pdfloadshow=false;
                        this.pdffileshow=true;
                    }).catch(error=>{
             
                        clearInterval(upProg)
                        this.progress=0;
                        this.pdferror=true;
                    })
                }).catch(e=>console.log(e))
            
           
        }).catch(error=>{
           clearInterval(upProg);
           this.progress=0;
           this.pdferror=true
           this.pdfloadshow=false;
        })
    }

    handlePdfDelete(e){
        deletepdfFiles({recordId:this.cmId}).then(data=>{
                this.pdf=''
                this.pdfname=''
                this.pdfchange=false;
                this.pdffileshow=false;
        }
        ).catch(error=>console.log(error))
    }

    handleFilesChange(e) {
        var files = e.target.files;
        var extension= files[0].type;
        this.filechange=false;
        this.getBase64(files[0]).then(data=>{
            // console.log(data);
            if (extension!='png'){
                var buff = data.split("/")[0].length +data.split("/")[1].length+1
                this.file=data.substring(buff, data.length);
                
                uploadFile({recordId: this.cmId}).then(data=>{
                    this.filesrc= URL.createObjectURL(files[0])
                    this.filename=files[0].name
                    this.filechange=true;
                }).catch(error=>{
                    console.log(error)
                
                })
            }
           
        }).catch(error=>{console.log(error)})
    }

 

    getBase64(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            var buff = reader.result.split("/")[0].length +reader.result.split("/")[1].length+1
            resolve(reader.result.substring(buff, reader.result.length));
          }
          
        
          reader.readAsDataURL(file);
          reader.onerror = error => reject(error);
        });
      }

    getPdfBase64(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve((reader.result).replace(/^[^,]*,/, ''));
          reader.readAsDataURL(file);
          
          reader.onerror = error => reject(error);
        });
      }

    updateProgress() {
        this.progress =this.progress === 100 ? 0 : this.progress + 10;
      
    }
    handleeditchange(e){
     
        switch (e.target.name){
            case 'colorphoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'enginephoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'mugphoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'mufflerphoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'spoilerphoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'lightphoto':
                this.handlepartsphotochange(e.target.name,e.target.files)
            case 'colorname':
                this.basecolors.Name=e.target.value
                break;
            
            case 'enginename':
                this.baseengines.Name=e.target.value
                break;
            case 'enginedescription':
                this.baseengines.Description__c=e.target.value
                break;
            case 'enginedetaileddescription':
                this.baseengines.Detailed_Description__c=e.target.value
                break;
            case 'enginecost':
                this.baseengines.Pricecost__c=Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100 
                this.baseengines.Price__c= (1+this.profitmargin)* (this.baseengines.Pricecost__c)
                this.baseenginecost=this.baseengines.Pricecost__c
                this.baseengineprice=this.baseengines.Price__c
                this.handlepartscostchange('engine');
                break;
            case 'mugname':
                    this.basemugs.Name=e.target.value
                    break;
            case 'mugdescription':
                    this.basemugs.Description__c=e.target.value
                    break;
            case 'mugdetaileddescription':
                    this.basemugs.Detailed_Description__c=e.target.value
                    break;
            case 'mugcost':
                    this.basemugs.Pricecost__c=Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100 
                    this.basemugs.Price__c= (1+this.profitmargin)* (this.basemugs.Pricecost__c)
                    this.basemugcost=this.basemugs.Pricecost__c
                    this.basemugprice=this.basemugs.Price__c
                    this.handlepartscostchange();
                    break;   
            case 'mufflername':
                    this.basemufflers.Name=e.target.value
                    break;
            case 'mufflerdescription':
                    this.basemufflers.Description__c=e.target.value
                    break;
            case 'mufflerdetaileddescription':
                   
                    this.basemufflers.Detailed_Description__c=e.target.value
                  
                    break;
            case 'mufflercost':
                    this.basemufflers.Pricecost__c=Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100 
                    this.basemufflers.Price__c= (1+this.profitmargin)* this.basemufflers.Pricecost__c
                    this.basemufflercost=this.basemufflers.Pricecost__c
                    this.basemufflerprice=this.basemufflers.Price__c
                    this.handlepartscostchange();
                    break;
            case 'spoilername':
                    this.basespoilers.Name=e.target.value
                    break;
            case 'spoilerdescription':
                    this.basespoilers.Description__c=e.target.value
                    break;
            case 'spoilerdetaileddescription':
                    this.basespoilers.Detailed_Description__c=e.target.value
                    break;
            case 'spoilercost':
                    this.basespoilers.Pricecost__c=Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100 
                    this.basespoilers.Price__c= (1+this.profitmargin)* this.basespoilers.Pricecost__c
                    this.basespoilercost=this.basespoilers.Pricecost__c
                    this.basespoilerprice=this.basespoilers.Price__c
                    this.handlepartscostchange();
                    break;
            case 'lightname':
                    this.baselights.Name=e.target.value
                    break;
            case 'lightdescription':
                    this.baselights.Description__c=e.target.value
                    break;
            case 'lightdetaileddescription':
                    this.baselights.Detailed_Description__c=e.target.value
                    break;
            case 'lightcost':
                    this.baselights.Pricecost__c=Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100 
                    this.baselights.Price__c= (1+this.profitmargin)* this.baselights.Pricecost__c
                    this.baselightrcost=this.baselights.Pricecost__c
                    this.baselightprice=this.baselights.Price__c
                    this.handlepartscostchange();
                    break;
             
        }
    }
    handlepartscostchange(){
        this.totalcost=this.cost + this.baseengines.Pricecost__c + 
        this.basemugs.Pricecost__c + this.basemufflers.Pricecost__c +
        this.baselights.Pricecost__c + this.basespoilers.Pricecost__c
        this.totalprice= Math.round((this.totalcost * (1+ this.profitmargin)+Number.EPSILON)*100)/100
    }

    handlepartsphotochange(type,files){
        switch(type){
            case 'enginephoto':
                this.baseengines.url=URL.createObjectURL(files[0])
                this.baseengineurl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.baseengines.filename=files[0].name
                    this.baseengines.file=data
                    this.baseengines.filechange=true
                   }
                )
                break;
               
            case 'colorphoto':
                this.basecolors.url=URL.createObjectURL(files[0])
                this.basecolorurl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.basecolors.filename=files[0].name
                    this.basecolors.file=data
                    this.basecolors.filechange=true
                   }
                )
                break;
            case 'mugphoto':
                this.basemugs.url=URL.createObjectURL(files[0])
                this.basemugurl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.basemugs.filename=files[0].name
                    this.basemugs.file=data
                    this.basemugs.filechange=true
                   }
                )
                break;
            case 'mufflerphoto':
                this.basemufflers.url=URL.createObjectURL(files[0])
                this.basemufflerurl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.basemufflers.filename=files[0].name
                    this.basemufflers.file=data
                    this.basemufflers.filechange
                   }
                )
                break;
            case 'spoilerphoto':
                this.basespoilers.url=URL.createObjectURL(files[0])
                this.basespoilerurl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.basespoilers.filename=files[0].name
                    this.basespoilers.file=data
                    this.basespoilers.filechange=true
                   }
                )
                break;
            case 'lightphoto':
                this.baselights.url=URL.createObjectURL(files[0])
                this.baselighturl=URL.createObjectURL(files[0])
                this.getBase64(files[0]).then(data=>{
                    this.baselights.filename=files[0].name
                    this.baselights.file=data
                    this.baselights.filechange=data
                   }
                )
                break;
        }
        
    }
    handlesave(e){
        const allValid = [ 
            ...this.template.querySelectorAll('lightning-input'),...this.template.querySelectorAll('lightning-textarea')
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){ 
        carmodeledit( {rid:this.cmId, Baseprice:this.price, Color:this.basecolors.Name,  
                       Cost:this.cost, Description:this.description, Detailed_Description:this.detaileddescription,
                       Profit_Margin:this.profitmargin, 
                       Engine:this.baseengines.Name, Enginecost:this.baseengines.Pricecost__c, Engineprice:this.baseengines.Price__c, 
                       Lightcost:this.baselights.Pricecost__c,Lightprice:this.baselights.Price__c, Lights:this.baselights.Name, 
                       Muffler:this.basemufflers.Name, Mufflercost:this.basemufflers.Pricecost__c, Mufflerprice:this.basemufflers.Price__c, 
                       Mugcost:this.basemugs.Pricecost__c,	Mugprice:this.basemugs.Price__c, Mugs:this.basemugs.Name,  
                       SpoilerCost:this.basespoilers.Pricecost__c, Spoilers:this.basespoilers.Name,SpoilersPrice:this.basespoilers.Price__c, 
                       Name:this.name,Status:this.status,TotalCost:this.totalcost, TotalPrice:this.totalprice, 
                       Year:this.year,page: 0,carperpage: 2})
                    .then(data=>{
                        
                       this.counter=0
                        if (this.baseengines.edited==false){
                            
                            carpartedit( {rid:this.baseengines.Id, name:this.baseengines.Name, price: this.baseengines.Price__c, 
                                          type:this.baseengines.Type__c, description:this.baseengines.Description__c,
                                          Detailed_Description:this.baseengines.Detailed_Description__c,
                                          pricecost:this.baseengines.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                            this.counter++
                                            if(this.baseengines.filechange){
                                                
                                                uploadFile({base64:this.baseengines.file,
                                                            filename:this.baseengines.filename,
                                                            recordId:data[0].Id}).then(data=>{
                                                                this.counter++
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            }).catch(e=>{console.log(e);
                                                                this.counter++;
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            })
                                            }else{
                                                
                                                this.counter++
                                               
                                                if (this.counter==12){
                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                        detail:'yes', bubbles:true, composed:true
                                                    },)
                                                    this.dispatchEvent(evt);
                                                }
                                                
                                            } 
                                          }).catch(e=>{console.log(e);this.counter=this.counter+2;
                                            if (this.counter==12){
                                                const evt = new CustomEvent('carmodeleditsave', {
                                                    detail:'yes', bubbles:true, composed:true
                                                },)
                                                this.dispatchEvent(evt);
                                            }
                                            })
                        }else{
                            this.counter=this.counter+2
                            if (this.counter==12){
                                const evt = new CustomEvent('carmodeleditsave', {
                                    detail:'yes', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(evt);
                            }
                        }


                        if (this.basemugs.edited==false){
                            
                            carpartedit( {rid:this.basemugs.Id, name:this.basemugs.Name, price: this.basemugs.Price__c, 
                                          type:this.basemugs.Type__c, description:this.basemugs.Description__c,
                                          Detailed_Description:this.basemugs.Detailed_Description__c,
                                          pricecost:this.basemugs.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                            this.counter++
                                            if(this.basemugs.filechange){
                                                uploadFile({base64:this.basemugs.file,
                                                            filename:this.basemugs.filename,
                                                            recordId:data[0].Id}).then(data=>{
                                                                this.counter++
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            }).catch(e=>{console.log(e);this.counter++;
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            })
                                            }else{
                                                this.counter++
                                                if (this.counter==12){
                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                        detail:'yes', bubbles:true, composed:true
                                                    },)
                                                    this.dispatchEvent(evt);
                                                }
                                                
                                            }  
                                          }).catch(e=>{console.log(e);this.counter=this.counter+2;
                                            if (this.counter==12){
                                                const evt = new CustomEvent('carmodeleditsave', {
                                                    detail:'yes', bubbles:true, composed:true
                                                },)
                                                this.dispatchEvent(evt);
                                            }
                                        })
                        }else{
                            this.counter=this.counter+2
                            
                            if (this.counter==12){
                                const evt = new CustomEvent('carmodeleditsave', {
                                    detail:'yes', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(evt);
                            }
                        }
                        if (this.basecolors.edited==false){
                            carpartedit( {rid:this.basecolors.Id, name:this.basecolors.Name, price: this.basecolors.Price__c, 
                                          type:this.basecolors.Type__c, description:this.basecolors.Description__c,
                                          Detailed_Description:this.basecolors.Detailed_Description__c,
                                          pricecost:this.basecolors.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                            this.counter++
                                            if(this.basecolors.filechange){
                                                uploadFile({base64:this.basecolors.file,
                                                            filename:this.basecolors.filename,
                                                            recordId:data[0].Id}).then(data=>{
                                                                this.counter++
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            }).catch(e=>{console.log(e);this.counter++;
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            })
                                            }else{
                                                this.counter++
                                                if (this.counter==12){
                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                        detail:'yes', bubbles:true, composed:true
                                                    },)
                                                    this.dispatchEvent(evt);
                                                }
                                                
                                            }  
                                          }).catch(e=>{console.log(e);this.counter=this.counter+2; 
                                            if (this.counter==12){
                                                const evt = new CustomEvent('carmodeleditsave', {
                                                detail:'yes', bubbles:true, composed:true
                                            },)
                                            this.dispatchEvent(evt);
                                        }})
                        }else{
                            this.counter=this.counter+2
                            if (this.counter==12){
                                const evt = new CustomEvent('carmodeleditsave', {
                                    detail:'yes', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(evt);
                            }
                        }
                        if (this.basemufflers.edited==false){
                          
                            carpartedit( {rid:this.basemufflers.Id, name:this.basemufflers.Name, price: this.basemufflers.Price__c, 
                                          type:this.basemufflers.Type__c, description:this.basemufflers.Description__c,
                                          Detailed_Description:this.basemufflers.Detailed_Description__c,
                                          pricecost:this.basemufflers.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                            this.counter++
                                            if(this.basemufflers.filechange){
                                                uploadFile({base64:this.basemufflers.file,
                                                            filename:this.basemufflers.filename,
                                                            recordId:data[0].Id}).then(data=>{
                                                                this.counter++
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            }).catch(e=>{console.log(e);this.counter++;
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            })
                                            }else{
                                                this.counter++
                                                if (this.counter==12){
                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                        detail:'yes', bubbles:true, composed:true
                                                    },)
                                                    this.dispatchEvent(evt);
                                                }
                                                
                                            }  
                                          }).catch(e=>{console.log(e);this.counter=this.counter+2;
                                            if (this.counter==12){
                                                const evt = new CustomEvent('carmodeleditsave', {
                                                    detail:'yes', bubbles:true, composed:true
                                                },)
                                                this.dispatchEvent(evt);
                                            }
                                        })
                        }else{
                            this.counter=this.counter+2
                            if (this.counter==12){
                                const evt = new CustomEvent('carmodeleditsave', {
                                    detail:'yes', bubbles:true, composed:true
                                },)
                                this.dispatchEvent(evt);
                            }
                        }
                        if (this.baselights.edited==false){
                            carpartedit( {rid:this.baselights.Id, name:this.baselights.Name, price: this.baselights.Price__c, 
                                          type:this.baselights.Type__c, description:this.baselights.Description__c,
                                          Detailed_Description:this.baselights.Detailed_Description__c,
                                          pricecost:this.baselights.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                            this.counter++
                                            if(this.baselights.filechange){
                                                uploadFile({base64:this.baselights.file,
                                                            filename:this.baselights.filename,
                                                            recordId:data[0].Id}).then(data=>{
                                                                this.counter++
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }else{
                                                                    this.counter++
                                                                    if (this.counter==12){
                                                                        const evt = new CustomEvent('carmodeleditsave', {
                                                                            detail:'yes', bubbles:true, composed:true
                                                                        },)
                                                                        this.dispatchEvent(evt);
                                                                    }
                                                                    
                                                                } 
                                                            }).catch(e=>{console.log(e);this.counter++;
                                                                if (this.counter==12){
                                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                                        detail:'yes', bubbles:true, composed:true
                                                                    },)
                                                                    this.dispatchEvent(evt);
                                                                }
                                                            })
                                            } 
                                          }).catch(e=>{console.log(e);this.counter=this.counter+2;
                                            if (this.counter==12){
                                                const evt = new CustomEvent('carmodeleditsave', {
                                                    detail:'yes', bubbles:true, composed:true
                                                },)
                                                this.dispatchEvent(evt);
                                            }
                                        })
                            }else{
                                this.counter=this.counter+2
                                if (this.counter==12){
                                    const evt = new CustomEvent('carmodeleditsave', {
                                        detail:'yes', bubbles:true, composed:true
                                    },)
                                    this.dispatchEvent(evt);
                                }
                            }
                        if (this.basespoilers.edited==false){
                                carpartedit( {rid:this.basespoilers.Id, name:this.basespoilers.Name, price: this.basespoilers.Price__c, 
                                              type:this.basespoilers.Type__c, description:this.basespoilers.Description__c,
                                              Detailed_Description:this.basespoilers.Detailed_Description__c,
                                              pricecost:this.basespoilers.Pricecost__c, base:true,page:0, carperpage:1}  ).then(data=>{
                                                this.counter++
                                                if(this.basespoilers.filechange){
                                                    uploadFile({base64:this.basespoilers.file,
                                                                filename:this.basespoilers.filename,
                                                                recordId:data[0].Id}).then(data=>{
                                                                    this.counter++
                                                                    if (this.counter==12){
                                                                        const evt = new CustomEvent('carmodeleditsave', {
                                                                            detail:'yes', bubbles:true, composed:true
                                                                        },)
                                                                        this.dispatchEvent(evt);
                                                                    }else{
                                                                        this.counter++
                                                                        if (this.counter==12){
                                                                            const evt = new CustomEvent('carmodeleditsave', {
                                                                                detail:'yes', bubbles:true, composed:true
                                                                            },)
                                                                            this.dispatchEvent(evt);
                                                                        }
                                                                        
                                                                    } 
                                                                }).catch(e=>{console.log(e);this.counter++;
                                                                    if (this.counter==12){
                                                                        const evt = new CustomEvent('carmodeleditsave', {
                                                                            detail:'yes', bubbles:true, composed:true
                                                                        },)
                                                                        this.dispatchEvent(evt);
                                                                    }
                                                                })
                                                } 
                                              }).catch(e=>{console.log(e);this.counter=this.counter+2;
                                                if (this.counter==12){
                                                    const evt = new CustomEvent('carmodeleditsave', {
                                                        detail:'yes', bubbles:true, composed:true
                                                    },)
                                                    this.dispatchEvent(evt);
                                                }
                                            })
                            }else{
                                this.counter=this.counter+2
                                if (this.counter==12){
                                    const evt = new CustomEvent('carmodeleditsave', {
                                        detail:'yes', bubbles:true, composed:true
                                    },)
                                    this.dispatchEvent(evt);
                                }
                            }
                    }).catch(e=>{console.log(e)})
                }
    }
    handleclose(){
        const evt = new CustomEvent('carmodeleditclose', {
            detail:'yes', bubbles:true, composed:true
        },)
        this.dispatchEvent(evt);
    }
}