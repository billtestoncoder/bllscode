import { LightningElement, wire,api,track } from 'lwc';
import gofetch from '@salesforce/apex/UserFetch.gofetch';
import carselect from '@salesforce/apex/CarController.carselect';
import carpartselectall from '@salesforce/apex/CarpartController.carpartselectall'
import getUrl from '@salesforce/apex/FileUploaderClass.getUrl'
import cardelete from '@salesforce/apex/CarController.cardelete';
import carmodelselect from '@salesforce/apex/CarmodelController.carmodelselect';
import carmodeldelete from '@salesforce/apex/CarmodelController.carmodeldelete';
import campaignselect from '@salesforce/apex/CampaignController.campaignselect';
import accountselect from '@salesforce/apex/AccountController.accountselect';
import contactselect from '@salesforce/apex/ContactController.contactselect';
import leadselect from '@salesforce/apex/LeadController.leadselect';
import { refreshApex } from '@salesforce/apex';

export default class Cartab extends LightningElement {
wiredResult
wiredmodelResult
wiredpartResult
wiredcampaignResult
wiredaccountResult
wiredleadResult
wiredcontactResult

@api carmodeleditopen=false
@api cardataload=0;
@api show=false;

@api cardata=[];
@api carIds=[];

@api carpartdata=[];
@api carpartIds=[];

@api carpart={};
@api carpartv={};

@api carmodeldata=[];
@api carmodelIds=[];

@api campaigndata=[];
@api campaigncar=[];

@api accountdata=[];
@api accountcar=[];

@api contactdata=[];
@api contact=[];
@api contactIds=[];

@api leaddata=[];
@api lead=[];
@api leadIds=[];
@api leadshow=false;
@api leadtype='create';

@api car={};
@api carurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder';

@api carmodel={};
@api carmodelchange={};

@api carmodelurl='https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder';

@api carshow=false;
@api careditshow=false;
@api carmodelshow=false
@api carmodelviewershow=false;
@api carmodeleditshow=false;

@api campaigncreatorshow=false;
@api campaignviewershow =false;

@api accountcreatorshow=false;
@api accountviewershow =false;

@api carparteditshow=false;
@api carpartcreateshow=false;
@api carpartviewshow=false

@api contactcreateshow=false;
@api contacteditshow=false;

@api userdata={};

@api page=0;
@api carperpage=25;

hello='hello'
@wire(gofetch,{hello:'$hello'})
Callbacked({data,error}){
   
    if ((typeof data)!='undefined' && (typeof error)=='undefined'){
   
        
        this.userdata.id=data[0].Id;  
        this.userdata.id=data[0].Id;  
       
    }
   
}

@wire(accountselect, {page:'$page',carperpage:'$carperpage'})
Accountselected(result){
    this.wiredaccountResult= result
    console.log(result)
    if (result.data){
        this.accountdata=result.data.map(d=>{return {...d,CarModelName:d.Car_Model__r.Name,'tablestyle':'tablecolor'}}); 
    }
}

@wire(contactselect, {page:'$page',carperpage:'$carperpage'})
Contacttselected(result){
    this.wiredcontactResult= result
    console.log(result)
    if (result.data){
        this.contactdata=result.data.map(d=>{return {...d,CarModelName:d.Car_Model__r.Name,'tablestyle':'tablecolor'}}); 
        this.contactdata.forEach(d=>{
            this.contactIds.push(d.Id)
        })
    }
}

@wire(leadselect, {page:'$page',carperpage:'$carperpage'})
Leadselected(result){
    this.wiredleadResult= result
    console.log(result)
    if (result.data){
        this.leaddata=result.data.map(d=>{return {...d,'tablestyle':'tablecolor'}}); 
        this.leaddata.forEach(cd=>{
          
            this.leadIds.push(cd.Id)
            
        }) 
    }
}

@wire(campaignselect, {page:'$page',carperpage:'$carperpage'})
Campaignselected(result){
    this.wiredcampaignResult= result
    console.log(result)
    if (result.data){
        this.campaigndata=result.data.map(d=>{return {...d,'tablestyle':'tablecolor'}}); 
       
    }
}


@wire(carselect, {page:'$page',carperpage:'$carperpage'})
Carselected(result){
    this.wiredResult=result
    if (result.data){
       
        this.carIds=[];
        
        this.cardata=result.data.map(d=>{return {...d,'tablestyle':'tablecolor'}}); 
        this.cardata.forEach(cd=>{
          
            this.carIds.push(cd.Id)
            
        }) 
     
    }
}

@wire(carpartselectall, {page:'$page',carperpage:'$carperpage'})
Carpartselected(result){
    this.wiredpartResult=result
        if (result.data){
      
        this.carpartIds=[];
        this.carpartdata=result.data.map(d=>{return {...d,'tablestyle':'tablecolor','Model':d.Car_Model__r.Name}}); 
        
        this.carpartdata.forEach(cd=>{
            this.carpartIds.push(cd.Id)
            
        }) 
     
    }
}

@wire(carmodelselect, {page:'$page',carperpage:'$carperpage'})
Carmodelselected(result){
    this.wiredmodelResult=result
    var data=result.data
    var error= result.error
    if(data){
        this.carmodelIds=[];
        var buffdata=[]
        
        data.forEach((d,n)=>{
            var datus= {...d,Carname:d.Car__r.Name,'tablestyle':'tablecolor'}
            buffdata.push(datus)
        
        })
        this.carmodeldata=buffdata;
       
        this.carmodeldata.forEach(cmd=>{
            this.carmodelIds.push(cmd.Id)
        })
       
    }else{
        console.log(error)
    }
    
}


handleshow(){
    this.show=true;
}
handleclose(e){
    this.show=false;
    if (e.detail.data.target){
       
    }else{
        this.carmodelchange= false
        refreshApex(this.wiredpartResult)
        refreshApex(this.wiredmodelResult)
        refreshApex(this.wiredResult)
        refreshApex(this.wiredcampaignResult)
    }
}


handlecarview(event){
    const row = Object.assign({},event.detail)
    getUrl({recordId:row.Id}).then(data=>{
        this.carurl= data;
        this.car = this.cardata[this.carIds.indexOf(row.Id)]
        this.carshow=true;
    })
    
}

handlecaredit(event){
    const row = Object.assign({},event.detail)
    getUrl({recordId:row.Id}).then(data=>{
        this.carurl= data;
        this.car = this.cardata[this.carIds.indexOf(row.Id)]
        this.careditshow=true;
    })
    
}
handlecardelete(event){
    const row = Object.assign({},event.detail)
    
    cardelete({Ids:[row.Id],page:this.page, carperpage: this.carperpage}).then(data=>{
        this.carmodelchange= false
        refreshApex(this.wiredpartResult)
        refreshApex(this.wiredmodelResult)
        refreshApex(this.wiredResult)
        refreshApex(this.wiredcampaignResult)
    
    })
    
}

handlecarmodelview(event){
    const row = Object.assign({},event.detail)
    
    this.carmodel = this.carmodeldata[this.carmodelIds.indexOf(row.Id)]
    
    this.carmodelviewershow=true;

}

handlecarmodelclose(event){

    this.carmodelviewershow=false;
    
}

handlecarmodeledit(event){
    const row = Object.assign({},event.detail)
    this.carmodel = this.carmodeldata[this.carmodelIds.indexOf(row.Id)]
    this.carmodelchange= true
    this.carmodeleditshow=true; 
    this.carmodeleditopen=true;
}
handleeditcarmodelclose(event){
    this.carmodeleditshow=false;
    this.carmodelchange= false;
}
handlecarmodeldelete(event){
    const row = Object.assign({},event.detail)
    
    carmodeldelete({Ids:[row.Id],page:this.page, carperpage: this.carperpage}).then(data=>{
        this.carmodelchange= false
        refreshApex(this.wiredpartResult)
        refreshApex(this.wiredmodelResult)
        refreshApex(this.wiredResult)
        refreshApex(this.wiredcampaignResult)
    
    })
    
}
handlecarmodeleditsave(e){
  
    this.carmodeleditshow=false
    refreshApex(this.wiredpartResult)
    refreshApex(this.wiredmodelResult)
    refreshApex(this.wiredResult)
    refreshApex(this.wiredcampaignResult)
    
}

handlecarmodelviewclose(e){
    this.carmodelviewershow=false;
}


handlesmodelshow(event){
    this.carmodelshow=true
   
}
handlecarclose(event){
    this.carshow=false;
}

handleeditcarclose(e){
    this.careditshow=false;
    if (e.detail.data.target){
       
    }else{
        this.carmodelchange= false
        refreshApex(this.wiredpartResult)
        refreshApex(this.wiredmodelResult)
        refreshApex(this.wiredResult)
        refreshApex(this.wiredcampaignResult)
    }
}



handlemodelclose(event){
    this.carmodelshow=false
}
handlemodelsave(event){
    this.carmodelshow=false
    this.carmodelchange= false
    refreshApex(this.wiredpartResult)
    refreshApex(this.wiredmodelResult)
    refreshApex(this.wiredResult)
    refreshApex(this.wiredcampaignResult)
}

handlecarparteditview(event){
    const row = Object.assign({},event.detail)
    getUrl({recordId:row.Id}).then(data=>{
        this.carpart = {...this.carpartdata[this.carpartIds.indexOf(row.Id)],url:data}
  
        this.carparteditshow=true
    })
   
}
handlecarparteditsave(event){
    this.carparteditshow=false
    this.carmodelchange= false
    refreshApex(this.wiredpartResult)
    refreshApex(this.wiredmodelResult)
    refreshApex(this.wiredResult)
    refreshApex(this.wiredcampaignResult)
}


handlecarparteditclose(event){
    this.carparteditshow=false
    this.carmodelchange= false
 
}

handlecarpartcreateview(event){
    this.carpartcreateshow=true
}


handlecarpartcreateclose(event){
    this.carpartcreateshow=false
 
}

handlecarpartcreatesave(event){
    this.carpartcreateshow=false
    refreshApex(this.wiredpartResult)
    refreshApex(this.wiredmodelResult)
    refreshApex(this.wiredResult)
    refreshApex(this.wiredcampaignResult)
}

handlecarpartviewerview(event){
    const row = Object.assign({},event.detail)
    getUrl({recordId:row.Id}).then(data=>{
        this.carpartv = {...this.carpartdata[this.carpartIds.indexOf(row.Id)],url:data}
      
        this.carpartviewshow=true
    })
   
}

handlecarpartviewclose(event){
    this.carpartviewshow=false
    
}


handlecampaigncreateview(event){
    const row = Object.assign({},event.detail)
    
    this.campaigncar=  {...this.carmodeldata[this.carmodelIds.indexOf(row.Id)]}
    this.campaigncreatorshow=true
    
}

handlecampaigncreateclose(event){
    
    this.campaigncreatorshow=false
}

handlecampaignsave(event){
    this.campaigncreatorshow=false;
    refreshApex(this.wiredcampaignResult)
}

handlecampaigncarmodelview(event){
    console.log('bill')
    const row = Object.assign({},event.detail)
    
    this.campaigncar=  {...this.carmodeldata[this.carmodelIds.indexOf(row.Id)]}
    this.campaignviewershow=true
}
handlecampaigncmviewclose(event){
    this.campaignviewershow=false
}

handleaccountcreateview(event){
    const row = Object.assign({},event.detail)
    
    this.accountcar=  {...this.carmodeldata[this.carmodelIds.indexOf(row.Id)]}
    this.accountcreatorshow=true
    
}

handleaccountcreateclose(event){
    this.accountcreatorshow=false
}

handleaccountsave(event){
    this.accountcreatorshow=false;
    refreshApex(this.wiredaccountResult)
}

handleaccountcarmodelview(event){
    console.log('bill')
    const row = Object.assign({},event.detail)
    
    this.accountcar=  {...this.carmodeldata[this.carmodelIds.indexOf(row.Id)]}
    this.accountviewershow=true
}
handleaccountcmviewclose(event){
    this.accountviewershow=false
}

handleleadcreate(){
    this.leadtype='create'
    this.leadshow=true

}
handleleadedit(event){
    this.leadtype="edit"
    const row = Object.assign({},event.detail)
    
    this.lead=  {...this.leaddata[this.leadIds.indexOf(row.Id)]}
    this.leadshow=true
}

handleleadclosed(){
    this.leadshow=false
}

handleleadsaved(e){
    this.leadshow=false
    
    if (e.detail.data[0]==='Closed - Converted'){
        console.log(e.detail.data[0])
        this.lead=  {...this.leaddata[this.leadIds.indexOf(e.detail.data[1])]}
        this.contactcreateshow=true;
    }
    refreshApex(this.wiredleadResult);
}

handlecontactcreatesaved(e){
    this.contactcreateshow=false;
    refreshApex(this.wiredcontactResult)
}
handlecontactcreateclosed(e){
    this.contactcreateshow=false;
}

handlecontactedit(event){
    console.log('bill')
    const row = Object.assign({},event.detail)
    this.contact=  {...this.contactdata[this.contactIds.indexOf(row.Id)]}
    this.contacteditshow=true;
}

handlecontacteditsaved(e){
    this.contacteditshow=false;
    refreshApex(this.wiredcontactResult);
}
handlecontacteditclosed(e){
    this.contacteditshow=false;
}
}