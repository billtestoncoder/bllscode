import { LightningElement,api } from 'lwc';

export default class Carviewer extends LightningElement {
    @api car
    @api show;
    @api carurl;
    closecarshow(){
        const event = new CustomEvent('carclosed', {
            detail: 'done', bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
        
    }
}