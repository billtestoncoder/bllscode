import { LightningElement, api } from 'lwc';
import carpartcreate from '@salesforce/apex/CarpartController.carpartcreate';
import carmodelprofitmargin from '@salesforce/apex/CarmodelController.carmodelprofitmargin'
import uploadFile from '@salesforce/apex/FileUploaderClass.uploadFile'
const options = [
    {'label': 'Color', 'value': 'Color'},
    {'label': 'Engine', 'value': 'Engine'},
    {'label': 'Mufflers', 'value': 'MUfflers'},
    {'label': 'Mugs', 'value': 'Mugs'},
    {'label': 'Spoilers', 'value': 'Spoilers'},
    {'label': 'Lights', 'value': 'Lights'},
]
export default class Carpartcreator extends LightningElement {
    options = options
    @api show
    @api rid
    @api name
    @api model
    @api type
    @api cost
    @api price;
    @api description;
    @api detaileddescription;
    @api base;   
    @api profitmargin 
    @api src
    @api filename=''
    @api file
    @api filechange=false;
    
    @api
    get cpshow(){
        return this.show
    }
    set cpshow(value){
        
        if (value==true){
         
            this.show=true
            this.name = ''
            this.type = ''
            this.cost = 0
            this.price = 0
            this.profitmargin = 0            
            this.base = false
            this.detaileddescription = ''
            this.description =''
            this.src = 'https://developer43-dev-ed--c.vf.force.com/resource/1659177255000/placeholder'
        }else{
            this.show=false;
        }
    }
    handlecarpartsearch(event){
        console.log(event.detail.data)
        this.rid=event.detail.data
        carmodelprofitmargin({recordId:this.rid}).then(data=>{

            if (typeof data==string){
                this.profitmargin=Math.round((parseFloat(data)+Number.EPSILON)*100)/100
                this.price = this.cost*this.profitmargin
            }else{
                this.profitmargin=data
                this.price = this.cost*this.profitmargin 
            }
            
        })

    }
    
    handlecarpartselect(event){
        console.log(event.detail.data)
        this.rid=event.detail.data
        carmodelprofitmargin({recordId:this.rid}).then(data=>{

            if (typeof data==string){
                this.profitmargin=Math.round((parseFloat(data)+Number.EPSILON)*100)/100
                this.price = this.cost*this.profitmargin
            }else{
                this.profitmargin=data
                this.price = this.cost*this.profitmargin 
            }
            
        })
    }

    handlenamechange(e){
        this.name=e.target.value
    }

    handletypechange(e){
        this.type=e.target.value
    }

    handlecostchange(e){
        if (parseFloat(e.target.value)!=NaN){
            this.cost =  Math.round((parseFloat(e.target.value)+Number.EPSILON)*100)/100
        }
    }

    handledetaileddescriptionchange(e){
        this.detaileddescription= e.target.value
    }

    handledescriptionchange(e){
        this.description= e.target.value
    }

 

    handlefilechange(e) {
        var files = e.target.files;
        var extension= files[0].type;
        this.getBase64(files[0]).then(data=>{
            console.log(data);
            if (extension!='png'){
                var buff = data.split("/")[0].length +data.split("/")[1].length+1
                this.file=data.substring(buff, data.length);
                this.src= URL.createObjectURL(files[0])
                this.filename=files[0].name
                this.filechange=true;
            }
           
        }).catch(error=>{console.log(error)})
    }

    getBase64(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.readAsDataURL(file);
          
          reader.onerror = error => reject(error);
        });
      }

    handlecreateSave(){
        const allValid = [ 
            ...this.template.querySelectorAll('lightning-input'),...this.template.querySelectorAll('lightning-textarea')
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){
            carpartcreate( {
                name:this.name, price:this.price, type:this.type, carmodel:this.rid, 
                description:this.description,detailed_description:this.detaileddescription,
                pricecost:this.cost, base:false, page:0, carperpage:2
            }).then(data=>{
                console.log(data)
                if (this.filechange){
                    uploadFile({base64:this.file,filename:this.filename,recordId:data[0].Id})
                    .then(data=>{
                       
                        this.filename=''
                        this.filechange=true
                        this.file=''
                        const ev = new CustomEvent('carpartcreatesave', {
                            detail:'yes', bubbles:true, composed:true
                        },)
                        this.dispatchEvent(ev);
                            
                    })
                    .catch(error=>{console.log(error)})
                }else{
                        
                        this.filename=''
                        this.filechange=true
                        this.file=''
                        const ev = new CustomEvent('carpartcreatesave', {
                            detail:'yes', bubbles:true, composed:true
                        },)
                        this.dispatchEvent(ev);
                } 
            }).catch(error=>console.log(error))    
            }else{
                alert('Please update the invalid form entries and try again.');
            }
    }

    handlecreateClose(){
        const ev = new CustomEvent('carpartcreateclose', {
            detail:'yes', bubbles:true, composed:true
        },)
        this.dispatchEvent(ev);
        
    }
 

}