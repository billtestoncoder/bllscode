import { LightningElement,api } from 'lwc';
import {loadStyle} from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/cartable'

const columns = [
    {label:'Name', fieldName:'Name',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Part Type', fieldName:'Type__c',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
    {label:'Model', fieldName:'Model',type:'text',cellAttributes:{class:{fieldName:'tablestyle'}}},
];

export default class Carpattable extends LightningElement {
    @api carpartdata
    isCssLoaded = false
    columns = columns;
    show=false

    
    

    constructor() {
        super();
        this.columns.push({ type: 'action', typeAttributes: { rowActions: this.getRowActions }, cellAttributes:{class:{fieldName:'tablestyle'}} })
            // Other column data here
    }

    getRowActions(row, doneCallback) {
        const actions = [];
            
                actions.push({
                    'label': 'View',
                    'iconName': 'utility:record_lookup',
                    'name': 'view'
                });

                actions.push({
                    'label': 'Edit',
                    'iconName': 'utility:edit',
                    'name': 'edit'
                });
                actions.push({
                    'label': 'Delete',
                    'iconName': 'utility:delete',
                    'name': 'delete'
                });
                setTimeout(() => {
                    doneCallback(actions);
                }, 200);
           
    }

    handleRowAction(e) {
        const action = e.detail.action;
        const row =   Object.assign({},e.detail.row);
        // const rows = Object.assign({}, this.cdata);
        // const rowIndex = rows.indexOf(row);
        // console.log (Object.assign({}, event.detail.row))
        switch (action.name) {
            case 'view':
                const event = new CustomEvent('carpartview', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(event);
                
                break;
            case 'delete':
                const evt = new CustomEvent('carpartdelete', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(evt);
               
                break;
            case 'edit':
                const ev = new CustomEvent('carpartedit', {
                    detail:row, bubbles:true, composed:true
                },)
                this.dispatchEvent(ev);
                break;
        }
    }
    renderedCallback(){ 
        if(this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(()=>{
            console.log("Loaded Successfully")
        }).catch(error=>{ 
            console.error("Error in loading the colors")
        })
    }

}