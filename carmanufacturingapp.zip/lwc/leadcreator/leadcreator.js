import { LightningElement, api } from 'lwc';
import leadcreate from '@salesforce/apex/LeadController.leadcreate'
import leadedit from '@salesforce/apex/LeadController.leadedit'

const options = [
    {'label': 'Open - Not Contacted', 'value': 'Open - Not Contacted'},
    {'label': 'Working - Contacted', 'value': 'Working - Contacted'},
    {'label': 'Closed - Converted', 'value': 'Closed - Converted'},
    {'label': 'Closed - Not Converted', 'value': 'Closed - Not Converted'},
]

	
	
	

export default class Leadcreator extends LightningElement {
    options=options;
    @api show=false
    @api lead
    @api type='create'
    @api firstname = ''
    @api lastname = ''
    @api title = ''
    @api mobile =''
    @api email=''
    @api status
    @api company=''
    @api address=''

    @api 
    get cmshow(){
        this.show
    }

    set cmshow(value){
        this.show=value
        if (value==true){
            
            this.create=this.type=='create'
            this.edit=this.type=='edit'
            if (this.create){
                this.firstname = ''
                this.lastname = ''
                this.title = ''
                this.mobile =''
                this.email=''
                this.status='Open - Not Contacted'
                this.company=''
                this.address=''
            }else{
                this.firstname = this.lead.FirstName
                this.lastname = this.lead.LastName 
                this.title = this.lead.Title
                this.mobile = this.lead.Mobile__c
                this.email= this.lead.Email
                this.status = this.lead.Status
                this.company =this.lead.Company
                this.address= this.lead.Address__c
            }
        }
    }

    handlefirstnamechange(e){
        this.firstname=e.target.value
    }

    handlelastnamechange(e){
        this.lastname=e.target.value
    }

    handletitlechange(e){
        this.title = e.target.value
    }

    handlemobilechange(e){
        this.mobile = e.target.value
    }

    handleemailchange(e){
        this.email = e.target.value
    }

    handlecompanychange(e){
        this.company = e.target.value
    }

    handleaddresschange(e){
        this.address = e.target.value
    }
    handlestatuschange(e){
        this.status=e.target.value
    }

    handleSave(){
        const allValid = [
            ...this.template.querySelectorAll('lightning-input'),
        ].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid){
            if (this.create){
                leadcreate({firstname:this.firstname, lastname:this.lastname,address:this.address, 
                            email:this.email,mobile:this.mobile, title:this.title, company:this.company }).then(data=>{
                                const event = new CustomEvent('leadsaved', {
                                    detail: {data:this.status}, bubbles:true, composed:true
                                },)
                                this.dispatchEvent(event);
                            })
            }else if (this.edit){
                leadedit({status:this.status,  recordId:this.lead.Id}).then(data=>{
                    const event = new CustomEvent('leadsaved', {
                        detail: {data:[this.status,this.lead.Id]}, bubbles:true, composed:true
                    },)
                    this.dispatchEvent(event);
                })
                    
            }
        }
    }
    handleClose(){
        const event = new CustomEvent('leadclosed', {
            detail: {data:'closed'}, bubbles:true, composed:true
        },)
        this.dispatchEvent(event);
    }



}